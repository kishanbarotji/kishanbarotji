from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

def get_weather(city):
    # Step 1: Geocoding to get lat/lon
    geo_url = "https://geocoding-api.open-meteo.com/v1/search"
    geo_params = {"name": city, "count": 1}
    geo_res = requests.get(geo_url, params=geo_params, timeout=10)
    geo_data = geo_res.json()
    if "results" not in geo_data or len(geo_data["results"]) == 0:
        return {"error": "City not found"}
    loc = geo_data["results"][0]
    lat, lon = loc["latitude"], loc["longitude"]

    # Step 2: Get weather forecast
    weather_url = "https://api.open-meteo.com/v1/forecast"
    weather_params = {
        "latitude": lat,
        "longitude": lon,
        "current_weather": True,
    }
    weather_res = requests.get(weather_url, params=weather_params, timeout=10)
    weather_data = weather_res.json()
    if "current_weather" not in weather_data:
        return {"error": "Weather data unavailable"}

    current = weather_data["current_weather"]
    return {
        "city": loc["name"],
        "country": loc.get("country", ""),
        "temperature": current["temperature"],
        "windspeed": current["windspeed"],
        "winddirection": current["winddirection"],
        "weathercode": current["weathercode"],
        "time": current["time"]
    }

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@app.route("/weather", methods=["POST"])
def weather():
    data = request.get_json(force=True)
    city = data.get("city")
    if not city:
        return jsonify({"error": "No city provided"}), 400
    return jsonify(get_weather(city))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)