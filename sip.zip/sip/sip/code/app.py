from flask import Flask, render_template_string, request, redirect, url_for, session, flash, get_flashed_messages, send_file, jsonify
import sqlite3
import hashlib
from datetime import datetime, date, timedelta
import random
import io
import csv
import os
import logging

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'your-secret-key-here-change-in-production')

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize database with better error handling
def init_db():
    try:
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS users
                     (id INTEGER PRIMARY KEY, username TEXT UNIQUE, email TEXT, 
                      password TEXT, age INTEGER, weight REAL, height REAL, 
                      goal TEXT, activity_level TEXT, created_at TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS progress (
                        id INTEGER PRIMARY KEY,
                        user_id INTEGER,
                        date TEXT,
                        weight REAL,
                        body_fat REAL,
                        sleep REAL,
                        water REAL,
                        meals TEXT,
                        workouts TEXT,
                        FOREIGN KEY(user_id) REFERENCES users(id)
                    )''')
        # Add unique constraint for user_id and date combination
        c.execute('''CREATE UNIQUE INDEX IF NOT EXISTS idx_user_date 
                     ON progress(user_id, date)''')
        conn.commit()
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Database initialization error: {e}")
    finally:
        conn.close()

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def validate_user_input(data, required_fields):
    """Validate user input data"""
    errors = []
    for field in required_fields:
        if field not in data or not data[field].strip():
            errors.append(f"{field.replace('_', ' ').title()} is required")
    return errors

# Enhanced diet and fitness data
DIET_PLANS = {
    'weight_loss': {
        'breakfast': ['Steel-cut oats with fresh berries and chia seeds', 'Greek yogurt parfait with almonds and honey', 'Veggie egg white scramble with spinach'],
        'lunch': ['Grilled chicken Caesar salad (light dressing)', 'Quinoa power bowl with roasted vegetables', 'Baked cod with steamed broccoli'],
        'dinner': ['Lean turkey meatballs with zucchini noodles', 'Hearty lentil and vegetable soup', 'Grilled salmon with roasted asparagus'],
        'snacks': ['Apple slices with almond butter', 'Cucumber hummus cups', 'Mixed nuts (1 oz portion)', 'Celery with peanut butter']
    },
    'muscle_gain': {
        'breakfast': ['High-protein pancakes with Greek yogurt', 'Chicken and brown rice power bowl', 'Protein smoothie with banana and oats'],
        'lunch': ['Grilled chicken breast with quinoa pilaf', 'Lean beef stir-fry with jasmine rice', 'Tuna avocado wrap with whole grain tortilla'],
        'dinner': ['Grass-fed steak with roasted sweet potato', 'Chicken tikka masala with basmati rice', 'Baked salmon with whole wheat pasta'],
        'snacks': ['Post-workout protein shake', 'Greek yogurt with granola and berries', 'Peanut butter banana sandwich', 'Trail mix with dried fruit']
    },
    'maintenance': {
        'breakfast': ['Balanced granola bowl with fresh fruit', 'Avocado toast with poached egg', 'Acai smoothie bowl with toppings'],
        'lunch': ['Mediterranean chicken wrap', 'Vegetable primavera pasta', 'Buddha bowl with tahini dressing'],
        'dinner': ['Balanced home-style meal', 'Wood-fired pizza with salad', 'Asian stir-fry with brown rice'],
        'snacks': ['Seasonal fresh fruit', 'Vanilla Greek yogurt', 'Mixed nuts and dried fruit', 'Dark chocolate (small piece)']
    }
}

WORKOUT_PLANS = {
    'beginner': {
        'cardio': ['20-minute brisk walk outdoors', '15-minute stationary bike ride', '10-minute dance workout video', '15-minute swimming'],
        'strength': ['Wall push-ups (10 reps)', 'Bodyweight squats (15 reps)', '30-second plank hold', 'Modified lunges (10 each leg)'],
        'flexibility': ['10-minute morning yoga routine', 'Basic full-body stretching', '15-minute relaxation yoga']
    },
    'intermediate': {
        'cardio': ['30-minute steady jog', '25-minute cycling workout', '20-minute HIIT circuit', '30-minute elliptical session'],
        'strength': ['Standard push-ups (20 reps)', 'Goblet squats (25 reps)', '1-minute plank hold', 'Dumbbell compound exercises'],
        'flexibility': ['20-minute vinyasa yoga', 'Dynamic warm-up routine', '25-minute flexibility flow']
    },
    'advanced': {
        'cardio': ['45-minute distance run', '40-minute spin class', '30-minute HIIT training', '60-minute cycling ride'],
        'strength': ['Weighted compound movements', 'Push-up variations (50 reps)', '2-minute plank challenge', 'Pull-ups and chin-ups'],
        'flexibility': ['45-minute hot yoga class', 'Advanced stretching routine', '30-minute mobility work']
    }
}

# Modern, responsive HTML template with enhanced styling
BASE_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>FitLife - Your Wellness Journey</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --card-bg: rgba(255, 255, 255, 0.1);
            --card-hover: rgba(255, 255, 255, 0.15);
            --accent-color: #ff6b6b;
            --accent-hover: #ff5252;
            --text-primary: #ffffff;
            --text-secondary: #e8e8e8;
            --success-color: #4caf50;
            --warning-color: #ff9800;
            --error-color: #f44336;
            --shadow-light: 0 4px 20px rgba(0, 0, 0, 0.1);
            --shadow-heavy: 0 8px 30px rgba(0, 0, 0, 0.3);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--primary-gradient);
            min-height: 100vh;
            color: var(--text-primary);
            display: flex;
            flex-direction: column;
            line-height: 1.6;
        }

        /* Navigation Styles */
        nav {
            background: rgba(0, 0, 0, 0.3);
            padding: 1.2rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow-heavy);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .logo {
            font-size: 2rem;
            font-weight: 800;
            color: var(--text-primary);
            letter-spacing: 1px;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logo i {
            color: var(--accent-color);
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .nav-links a {
            color: var(--text-secondary);
            text-decoration: none;
            font-weight: 500;
            padding: 0.8rem 1.2rem;
            border-radius: 25px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .nav-links a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-primary);
            transform: translateY(-2px);
        }

        /* Container and Layout */
        .container {
            flex-grow: 1;
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
            width: 100%;
        }

        .card {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 2.5rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-heavy);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }

        .card:hover {
            background: var(--card-hover);
            transform: translateY(-2px);
        }

        /* Typography */
        h1 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            background: linear-gradient(45deg, #fff, #ff6b6b);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        h2 {
            font-size: 2rem;
            font-weight: 600;
            margin-bottom: 1.2rem;
            color: var(--text-primary);
        }

        h3 {
            font-size: 1.4rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: var(--text-primary);
        }

        p {
            font-size: 1rem;
            line-height: 1.7;
            margin-bottom: 1rem;
            color: var(--text-secondary);
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--text-primary);
            font-size: 0.95rem;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 1rem 1.2rem;
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-primary);
            font-size: 1rem;
            outline: none;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 3px rgba(255, 107, 107, 0.2);
            background: rgba(255, 255, 255, 0.15);
        }

        .form-group input::placeholder,
        .form-group textarea::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }

        /* Button Styles */
        .btn {
            background: linear-gradient(135deg, var(--accent-color), var(--accent-hover));
            color: white;
            padding: 1rem 2rem;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 600;
            font-size: 1rem;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(255, 107, 107, 0.3);
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(255, 107, 107, 0.4);
            text-decoration: none;
            color: white;
        }

        .btn-secondary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .btn-secondary:hover {
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }

        /* Grid Layouts */
        .grid-2 {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
        }

        .grid-auto {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
        }

        .grid-3 {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
        }

        /* Plan Cards */
        .plan-card {
            background: var(--card-bg);
            padding: 2rem;
            border-radius: 16px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
            backdrop-filter: blur(15px);
            position: relative;
            overflow: hidden;
        }

        .plan-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--accent-color), #667eea);
        }

        .plan-card:hover {
            transform: translateY(-5px);
            background: var(--card-hover);
            box-shadow: 0 12px 35px rgba(0, 0, 0, 0.3);
        }

        .plan-card h3 {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            font-size: 1.3rem;
            margin-bottom: 1.2rem;
        }

        .plan-card ul {
            list-style: none;
            padding: 0;
        }

        .plan-card li {
            padding: 0.5rem 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            position: relative;
            padding-left: 1.5rem;
        }

        .plan-card li::before {
            content: '▸';
            position: absolute;
            left: 0;
            color: var(--accent-color);
            font-weight: bold;
        }

        .plan-card li:last-child {
            border-bottom: none;
        }

        /* Flash Messages */
        .flash-messages {
            list-style: none;
            margin-bottom: 1.5rem;
        }

        .flash-messages li {
            background: linear-gradient(135deg, var(--error-color), #d32f2f);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 1rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.8rem;
            box-shadow: 0 4px 15px rgba(244, 67, 54, 0.3);
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Stats and Info Cards */
        .stats-card {
            background: var(--card-bg);
            padding: 1.5rem;
            border-radius: 16px;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            transition: all 0.3s ease;
        }

        .stats-card:hover {
            background: var(--card-hover);
            transform: scale(1.02);
        }

        .stats-card i {
            font-size: 2.5rem;
            color: var(--accent-color);
            margin-bottom: 1rem;
        }

        .stats-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
        }

        .stats-label {
            font-size: 0.9rem;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Progress Entries */
        .progress-entries {
            max-height: 400px;
            overflow-y: auto;
            padding-right: 0.5rem;
        }

        .progress-entry {
            background: var(--card-bg);
            padding: 1.5rem;
            margin-bottom: 1rem;
            border-radius: 12px;
            border-left: 4px solid var(--accent-color);
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
        }

        .progress-entry:hover {
            background: var(--card-hover);
            transform: translateX(5px);
        }

        .progress-date {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--accent-color);
            margin-bottom: 0.8rem;
        }

        .progress-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 0.5rem;
            font-size: 0.9rem;
        }

        /* Utility Classes */
        .center {
            text-align: center;
        }

        .text-center {
            text-align: center;
        }

        .mb-2 {
            margin-bottom: 2rem;
        }

        .mt-2 {
            margin-top: 2rem;
        }

        .flex {
            display: flex;
            gap: 1rem;
            align-items: center;
            justify-content: center;
            flex-wrap: wrap;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            nav {
                padding: 1rem;
                flex-direction: column;
                gap: 1rem;
            }

            .nav-links {
                flex-wrap: wrap;
                justify-content: center;
            }

            .container {
                margin: 1rem auto;
                padding: 0 0.5rem;
            }

            .card {
                padding: 1.5rem;
            }

            h1 {
                font-size: 2rem;
            }

            .grid-2,
            .grid-auto,
            .grid-3 {
                grid-template-columns: 1fr;
            }
        }

        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: var(--accent-color);
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        /* Chart Container */
        .chart-container {
            position: relative;
            height: 400px;
            margin: 2rem 0;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            padding: 1rem;
        }

        /* Custom Scrollbar */
        .progress-entries::-webkit-scrollbar {
            width: 6px;
        }

        .progress-entries::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 3px;
        }

        .progress-entries::-webkit-scrollbar-thumb {
            background: var(--accent-color);
            border-radius: 3px;
        }

        /* Notification Styles */
        .notification {
            background: linear-gradient(135deg, var(--accent-color), var(--accent-hover));
            color: white;
            padding: 1.2rem 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            box-shadow: var(--shadow-light);
            animation: slideIn 0.5s ease-out;
        }

        .notification i {
            font-size: 1.5rem;
        }

        /* Interactive Elements */
        .interactive-card {
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .interactive-card:hover {
            transform: translateY(-3px) scale(1.01);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
        }

        /* Form Enhancements */
        .form-row {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .form-row .form-group {
            flex: 1;
            margin-bottom: 0;
        }

        /* Success States */
        .success {
            background: linear-gradient(135deg, var(--success-color), #45a049) !important;
        }

        /* Error States */
        .error {
            border-color: var(--error-color) !important;
            box-shadow: 0 0 0 3px rgba(244, 67, 54, 0.2) !important;
        }
    </style>
</head>
<body>
    {% if user_logged_in %}
    <nav>
        <div class="logo">
            <i class="fas fa-heartbeat"></i>
            FitLife
        </div>
        <div class="nav-links">
            <a href="/dashboard"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="/diet_plan"><i class="fas fa-utensils"></i> Diet</a>
            <a href="/fitness_plan"><i class="fas fa-dumbbell"></i> Fitness</a>
            <a href="/progress"><i class="fas fa-chart-line"></i> Progress</a>
            <a href="/logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </nav>
    {% endif %}
    
    <div class="container">
        {% if flash_messages %}
            <div class="flash-messages">
                {% for message in flash_messages %}
                    <li><i class="fas fa-exclamation-triangle"></i> {{ message }}</li>
                {% endfor %}
            </div>
        {% endif %}
        {{ content|safe }}
    </div>
</body>
</html>
'''

# Enhanced Routes with better error handling

@app.route('/')
def home():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    
    content = '''
    <div class="card text-center" style="max-width: 600px; margin: 4rem auto; background: rgba(255,255,255,0.15);">
        <div style="margin-bottom: 2rem;">
            <i class="fas fa-heartbeat" style="font-size: 4rem; color: var(--accent-color); margin-bottom: 1rem;"></i>
            <h1 style="font-size: 3rem; margin-bottom: 1rem;">FitLife</h1>
            <p style="font-size: 1.3rem; margin-bottom: 2rem; color: var(--text-secondary);">
                Transform your health journey with personalized diet and fitness plans
            </p>
        </div>
        
        <div class="flex" style="justify-content: center; margin-top: 2rem;">
            <a href="/register" class="btn">
                <i class="fas fa-user-plus"></i>
                Get Started Free
            </a>
            <a href="/login" class="btn btn-secondary">
                <i class="fas fa-sign-in-alt"></i>
                Login
            </a>
        </div>
    </div>
    '''
    return render_template_string(BASE_TEMPLATE, content=content, user_logged_in=False, flash_messages=get_flashed_messages())

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            # Validate input
            required_fields = ['username', 'email', 'password', 'age', 'weight', 'height', 'goal', 'activity_level']
            errors = validate_user_input(request.form, required_fields)
            
            if errors:
                for error in errors:
                    flash(error)
                return redirect(url_for('register'))

            username = request.form['username'].strip()
            email = request.form['email'].strip()
            password = request.form['password']
            
            # Additional validation
            if len(username) < 3:
                flash('Username must be at least 3 characters long')
                return redirect(url_for('register'))
            
            if len(password) < 6:
                flash('Password must be at least 6 characters long')
                return redirect(url_for('register'))
            
            age = int(request.form['age'])
            weight = float(request.form['weight'])
            height = float(request.form['height'])
            
            if not (13 <= age <= 120):
                flash('Age must be between 13 and 120')
                return redirect(url_for('register'))
            
            if not (30 <= weight <= 500):
                flash('Weight must be between 30 and 500 kg')
                return redirect(url_for('register'))
            
            if not (100 <= height <= 250):
                flash('Height must be between 100 and 250 cm')
                return redirect(url_for('register'))

            goal = request.form['goal']
            activity_level = request.form['activity_level']
            
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            c.execute('''INSERT INTO users (username, email, password, age, weight, height, goal, activity_level, created_at)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                      (username, email, hash_password(password), age, weight, height, goal, activity_level, datetime.now().isoformat()))
            conn.commit()
            flash('Registration successful! Welcome to FitLife!')
            return redirect(url_for('login'))
            
        except sqlite3.IntegrityError:
            flash('Username already exists! Please choose a different one.')
        except ValueError as e:
            flash('Please enter valid numeric values for age, weight, and height')
        except Exception as e:
            logger.error(f"Registration error: {e}")
            flash('An error occurred during registration. Please try again.')
        finally:
            if 'conn' in locals():
                conn.close()
                
    content = '''
    <div class="card" style="max-width: 700px; margin: 0 auto;">
        <h2><i class="fas fa-user-plus"></i> Create Your FitLife Account</h2>
        <p style="margin-bottom: 2rem; color: var(--text-secondary);">Join thousands on their wellness journey</p>
        
        <form method="POST" novalidate>
            <div class="form-row">
                <div class="form-group">
                    <label for="username"><i class="fas fa-user"></i> Username:</label>
                    <input id="username" type="text" name="username" required autocomplete="username" 
                           placeholder="Choose a unique username" minlength="3" />
                </div>
                <div class="form-group">
                    <label for="email"><i class="fas fa-envelope"></i> Email:</label>
                    <input id="email" type="email" name="email" required autocomplete="email" 
                           placeholder="your@email.com" />
                </div>
            </div>
            
            <div class="form-group">
                <label for="password"><i class="fas fa-lock"></i> Password:</label>
                <input id="password" type="password" name="password" required autocomplete="new-password" 
                       placeholder="At least 6 characters" minlength="6" />
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="age"><i class="fas fa-birthday-cake"></i> Age:</label>
                    <input id="age" type="number" name="age" min="13" max="120" required placeholder="25" />
                </div>
                <div class="form-group">
                    <label for="weight"><i class="fas fa-weight"></i> Weight (kg):</label>
                    <input id="weight" type="number" step="0.1" name="weight" min="30" max="500" required placeholder="70.0" />
                </div>
            </div>
            
            <div class="form-group">
                <label for="height"><i class="fas fa-ruler-vertical"></i> Height (cm):</label>
                <input id="height" type="number" name="height" min="100" max="250" required placeholder="175" />
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="goal"><i class="fas fa-bullseye"></i> Goal:</label>
                    <select id="goal" name="goal" required>
                        <option value="" disabled selected>Select your fitness goal</option>
                        <option value="weight_loss">🔥 Weight Loss</option>
                        <option value="muscle_gain">💪 Muscle Gain</option>
                        <option value="maintenance">⚖️ Maintenance</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="activity_level"><i class="fas fa-running"></i> Activity Level:</label>
                    <select id="activity_level" name="activity_level" required>
                        <option value="" disabled selected>Select your current level</option>
                        <option value="beginner">🌱 Beginner</option>
                        <option value="intermediate">🚀 Intermediate</option>
                        <option value="advanced">⭐ Advanced</option>
                    </select>
                </div>
            </div>
            
            <button type="submit" class="btn" style="width: 100%; margin-top: 1rem;">
                <i class="fas fa-rocket"></i>
                Start My Journey
            </button>
            
            <p style="margin-top: 1.5rem; text-align: center; color: var(--text-secondary);">
                Already have an account? 
                <a href="/login" style="color: var(--accent-color); font-weight: 600;">Login here</a>
            </p>
        </form>
    </div>
    '''
    return render_template_string(BASE_TEMPLATE, content=content, user_logged_in=False, flash_messages=get_flashed_messages())

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        try:
            username = request.form.get('username', '').strip()
            password = request.form.get('password', '')
            
            if not username or not password:
                flash('Please enter both username and password')
                return redirect(url_for('login'))
                
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            c.execute('SELECT * FROM users WHERE username = ? AND password = ?', 
                     (username, hash_password(password)))
            user = c.fetchone()
            conn.close()
            
            if user:
                session['user_id'] = user[0]
                session['username'] = user[1]
                flash(f'Welcome back, {user[1]}!')
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid username or password!')
                
        except Exception as e:
            logger.error(f"Login error: {e}")
            flash('An error occurred during login. Please try again.')
        finally:
            if 'conn' in locals():
                conn.close()
                
    content = '''
    <div class="card" style="max-width: 500px; margin: 4rem auto;">
        <h2><i class="fas fa-sign-in-alt"></i> Welcome Back</h2>
        <p style="margin-bottom: 2rem; color: var(--text-secondary);">Continue your wellness journey</p>
        
        <form method="POST" novalidate>
            <div class="form-group">
                <label for="username"><i class="fas fa-user"></i> Username:</label>
                <input id="username" type="text" name="username" required autocomplete="username" 
                       placeholder="Enter your username" />
            </div>
            <div class="form-group">
                <label for="password"><i class="fas fa-lock"></i> Password:</label>
                <input id="password" type="password" name="password" required autocomplete="current-password" 
                       placeholder="Enter your password" />
            </div>
            
            <button type="submit" class="btn" style="width: 100%; margin-top: 1rem;">
                <i class="fas fa-sign-in-alt"></i>
                Login to FitLife
            </button>
            
            <p style="margin-top: 1.5rem; text-align: center; color: var(--text-secondary);">
                New to FitLife? 
                <a href="/register" style="color: var(--accent-color); font-weight: 600;">Create account</a>
            </p>
        </form>
    </div>
    '''
    return render_template_string(BASE_TEMPLATE, content=content, user_logged_in=False, flash_messages=get_flashed_messages())

@app.route('/logout')
def logout():
    username = session.get('username', 'User')
    session.clear()
    flash(f'Goodbye, {username}! See you next time.')
    return redirect(url_for('home'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash('Please login to access your dashboard')
        return redirect(url_for('login'))
        
    try:
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],))
        user = c.fetchone()
        
        if not user:
            session.clear()
            flash('User not found. Please login again.')
            return redirect(url_for('login'))

        # Check if progress logged today
        today_str = date.today().isoformat()
        c.execute('SELECT id FROM progress WHERE user_id = ? AND date = ?', (session['user_id'], today_str))
        progress_today = c.fetchone()
        
        # Get recent progress for streak calculation
        week_ago = (date.today() - timedelta(days=7)).isoformat()
        c.execute('SELECT COUNT(*) FROM progress WHERE user_id = ? AND date > ?', (session['user_id'], week_ago))
        weekly_logs = c.fetchone()[0]
        
        conn.close()
        
        # Calculate BMI and BMI category
        height_m = user[6] / 100 if user[6] > 0 else 1
        bmi = user[5] / (height_m ** 2) if height_m > 0 else 0
        
        bmi_category = "Normal"
        if bmi < 18.5:
            bmi_category = "Underweight"
        elif bmi >= 25:
            bmi_category = "Overweight"
        elif bmi >= 30:
            bmi_category = "Obese"

        # Progress reminder
        reminder_html = ''
        if not progress_today:
            reminder_html = '''
            <div class="notification">
                <i class="fas fa-bell"></i>
                <div>
                    <strong>Daily Check-in Reminder</strong><br>
                    Don't forget to log your progress today! <a href="/progress" style="color: white; text-decoration: underline;">Log now</a>
                </div>
            </div>
            '''

        content = f'''
        <div class="card">
            <h1><i class="fas fa-home"></i> Welcome back, {session['username']}!</h1>
            {reminder_html}
            
            <div class="grid-3 mb-2">
                <div class="stats-card">
                    <i class="fas fa-weight"></i>
                    <div class="stats-value">{user[5]} kg</div>
                    <div class="stats-label">Current Weight</div>
                </div>
                <div class="stats-card">
                    <i class="fas fa-chart-line"></i>
                    <div class="stats-value">{round(bmi, 1)}</div>
                    <div class="stats-label">BMI ({bmi_category})</div>
                </div>
                <div class="stats-card">
                    <i class="fas fa-fire"></i>
                    <div class="stats-value">{weekly_logs}</div>
                    <div class="stats-label">Weekly Logs</div>
                </div>
            </div>
            
            <div class="grid-2">
                <div class="plan-card interactive-card">
                    <h3><i class="fas fa-user"></i> Your Profile</h3>
                    <div style="line-height: 2;">
                        <p><i class="fas fa-birthday-cake" style="color: var(--accent-color);"></i> <strong>Age:</strong> {user[4]} years</p>
                        <p><i class="fas fa-ruler-vertical" style="color: var(--accent-color);"></i> <strong>Height:</strong> {user[6]} cm</p>
                        <p><i class="fas fa-bullseye" style="color: var(--accent-color);"></i> <strong>Goal:</strong> {user[7].replace('_', ' ').title()}</p>
                        <p><i class="fas fa-running" style="color: var(--accent-color);"></i> <strong>Activity:</strong> {user[8].title()}</p>
                    </div>
                </div>
                
                <div class="plan-card interactive-card">
                    <h3><i class="fas fa-rocket"></i> Quick Actions</h3>
                    <div style="display: flex; flex-direction: column; gap: 1rem;">
                        <a href="/diet_plan" class="btn" style="justify-content: center;">
                            <i class="fas fa-utensils"></i> View Diet Plan
                        </a>
                        <a href="/fitness_plan" class="btn" style="justify-content: center;">
                            <i class="fas fa-dumbbell"></i> View Fitness Plan
                        </a>
                        <a href="/progress" class="btn" style="justify-content: center;">
                            <i class="fas fa-plus-circle"></i> Log Progress
                        </a>
                    </div>
                </div>
            </div>
        </div>
        '''
        
    except Exception as e:
        logger.error(f"Dashboard error: {e}")
        flash('Error loading dashboard. Please try again.')
        return redirect(url_for('home'))
        
    return render_template_string(BASE_TEMPLATE, content=content, user_logged_in=True, flash_messages=get_flashed_messages())

@app.route('/diet_plan')
def diet_plan():
    if 'user_id' not in session:
        flash('Please login to view your diet plan')
        return redirect(url_for('login'))
        
    try:
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute('SELECT goal FROM users WHERE id = ?', (session['user_id'],))
        result = c.fetchone()
        
        if not result:
            session.clear()
            flash('User not found. Please login again.')
            return redirect(url_for('login'))
            
        goal = result[0]
        conn.close()
        
        plan = DIET_PLANS.get(goal, DIET_PLANS['maintenance'])
        daily_plan = {
            'breakfast': random.choice(plan['breakfast']),
            'lunch': random.choice(plan['lunch']),
            'dinner': random.choice(plan['dinner']),
            'snacks': random.sample(plan['snacks'], min(2, len(plan['snacks'])))
        }
        
        snacks_html = ''.join([f'<li>{snack}</li>' for snack in daily_plan['snacks']])
        
        content = f'''
        <div class="card">
            <h1><i class="fas fa-utensils"></i> Your Personalized Diet Plan</h1>
            <p style="margin-bottom: 2rem; font-size: 1.2rem; color: var(--text-secondary);">
                Customized for your goal: <strong style="color: var(--accent-color);">{goal.replace('_', ' ').title()}</strong>
            </p>
            
            <div class="grid-2 mb-2">
                <div class="plan-card" style="background: linear-gradient(135deg, #4caf50, #45a049);">
                    <h3><i class="fas fa-sun"></i> Breakfast</h3>
                    <p style="font-size: 1.1rem; line-height: 1.6;">{daily_plan['breakfast']}</p>
                </div>
                <div class="plan-card" style="background: linear-gradient(135deg, #ff9800, #f57c00);">
                    <h3><i class="fas fa-sun"></i> Lunch</h3>
                    <p style="font-size: 1.1rem; line-height: 1.6;">{daily_plan['lunch']}</p>
                </div>
                <div class="plan-card" style="background: linear-gradient(135deg, #2196f3, #1976d2);">
                    <h3><i class="fas fa-moon"></i> Dinner</h3>
                    <p style="font-size: 1.1rem; line-height: 1.6;">{daily_plan['dinner']}</p>
                </div>
                <div class="plan-card" style="background: linear-gradient(135deg, #9c27b0, #7b1fa2);">
                    <h3><i class="fas fa-cookie-bite"></i> Snacks</h3>
                    <ul style="margin: 0; padding: 0;">{snacks_html}</ul>
                </div>
            </div>
            
            <div class="text-center">
                <a href="/diet_plan" class="btn">
                    <i class="fas fa-sync-alt"></i>
                    Generate New Plan
                </a>
                <a href="/dashboard" class="btn btn-secondary" style="margin-left: 1rem;">
                    <i class="fas fa-arrow-left"></i>
                    Back to Dashboard
                </a>
            </div>
        </div>
        '''
        
    except Exception as e:
        logger.error(f"Diet plan error: {e}")
        flash('Error loading diet plan. Please try again.')
        return redirect(url_for('dashboard'))
        
    return render_template_string(BASE_TEMPLATE, content=content, user_logged_in=True, flash_messages=get_flashed_messages())

@app.route('/fitness_plan')
def fitness_plan():
    if 'user_id' not in session:
        flash('Please login to view your fitness plan')
        return redirect(url_for('login'))
        
    try:
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute('SELECT activity_level FROM users WHERE id = ?', (session['user_id'],))
        result = c.fetchone()
        
        if not result:
            session.clear()
            flash('User not found. Please login again.')
            return redirect(url_for('login'))
            
        activity_level = result[0]
        conn.close()
        
        plan = WORKOUT_PLANS.get(activity_level, WORKOUT_PLANS['beginner'])

        def list_items(items):
            return ''.join(f'<li>{item}</li>' for item in items)

        content = f'''
        <div class="card">
            <h1><i class="fas fa-dumbbell"></i> Your Personalized Fitness Plan</h1>
            <p style="margin-bottom: 2rem; font-size: 1.2rem; color: var(--text-secondary);">
                Tailored for: <strong style="color: var(--accent-color);">{activity_level.title()}</strong> level
            </p>
            
            <div class="grid-3 mb-2">
                <div class="plan-card" style="background: linear-gradient(135deg, #f44336, #d32f2f);">
                    <h3><i class="fas fa-heart"></i> Cardio</h3>
                    <ul>{list_items(plan['cardio'])}</ul>
                </div>
                <div class="plan-card" style="background: linear-gradient(135deg, #3f51b5, #303f9f);">
                    <h3><i class="fas fa-dumbbell"></i> Strength</h3>
                    <ul>{list_items(plan['strength'])}</ul>
                </div>
                <div class="plan-card" style="background: linear-gradient(135deg, #009688, #00796b);">
                    <h3><i class="fas fa-leaf"></i> Flexibility</h3>
                    <ul>{list_items(plan['flexibility'])}</ul>
                </div>
            </div>
            
            <div class="text-center">
                <a href="/fitness_plan" class="btn">
                    <i class="fas fa-sync-alt"></i>
                    Generate New Plan
                </a>
                <a href="/dashboard" class="btn btn-secondary" style="margin-left: 1rem;">
                    <i class="fas fa-arrow-left"></i>
                    Back to Dashboard
                </a>
            </div>
        </div>
        '''
        
    except Exception as e:
        logger.error(f"Fitness plan error: {e}")
        flash('Error loading fitness plan. Please try again.')
        return redirect(url_for('dashboard'))
        
    return render_template_string(BASE_TEMPLATE, content=content, user_logged_in=True, flash_messages=get_flashed_messages())

@app.route('/progress', methods=['GET', 'POST'])
def progress():
    if 'user_id' not in session:
        flash('Please login to track your progress')
        return redirect(url_for('login'))

    if request.method == 'POST':
        try:
            date_str = request.form.get('date', '').strip()
            if not date_str:
                flash('Date is required')
                return redirect(url_for('progress'))

            # Validate and parse optional numeric fields
            weight = None
            body_fat = None
            sleep = None
            water = None
            
            if request.form.get('weight'):
                weight = float(request.form['weight'])
                if not (30 <= weight <= 500):
                    flash('Weight must be between 30 and 500 kg')
                    return redirect(url_for('progress'))
                    
            if request.form.get('body_fat'):
                body_fat = float(request.form['body_fat'])
                if not (5 <= body_fat <= 50):
                    flash('Body fat percentage must be between 5% and 50%')
                    return redirect(url_for('progress'))
                    
            if request.form.get('sleep'):
                sleep = float(request.form['sleep'])
                if not (0 <= sleep <= 24):
                    flash('Sleep hours must be between 0 and 24')
                    return redirect(url_for('progress'))
                    
            if request.form.get('water'):
                water = float(request.form['water'])
                if not (0 <= water <= 10):
                    flash('Water intake must be between 0 and 10 liters')
                    return redirect(url_for('progress'))

            meals = request.form.get('meals', '').strip()
            workouts = request.form.get('workouts', '').strip()

            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            
            # Check if entry exists for this date
            c.execute('SELECT id FROM progress WHERE user_id = ? AND date = ?', (session['user_id'], date_str))
            existing = c.fetchone()
            
            if existing:
                c.execute('''UPDATE progress SET weight = ?, body_fat = ?, sleep = ?, water = ?, meals = ?, workouts = ? 
                             WHERE id = ?''',
                          (weight, body_fat, sleep, water, meals, workouts, existing[0]))
                flash('Progress updated successfully!')
            else:
                c.execute('''INSERT INTO progress (user_id, date, weight, body_fat, sleep, water, meals, workouts)
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                          (session['user_id'], date_str, weight, body_fat, sleep, water, meals, workouts))
                flash('Progress logged successfully!')
                
            conn.commit()
            
        except ValueError as e:
            flash('Please enter valid numeric values')
        except Exception as e:
            logger.error(f"Progress logging error: {e}")
            flash('An error occurred while saving progress. Please try again.')
        finally:
            if 'conn' in locals():
                conn.close()
        
        return redirect(url_for('progress'))

    # GET: show form and recent entries
    try:
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute('''SELECT date, weight, body_fat, sleep, water, meals, workouts 
                     FROM progress WHERE user_id = ? ORDER BY date DESC LIMIT 10''', (session['user_id'],))
        entries = c.fetchall()
        conn.close()

        entries_html = ''
        if entries:
            for entry in entries:
                entries_html += f'''
                <div class="progress-entry">
                    <div class="progress-date"><i class="fas fa-calendar"></i> {entry[0]}</div>
                    <div class="progress-details">
                        <span><i class="fas fa-weight"></i> Weight: {f"{entry[1]} kg" if entry[1] is not None else "Not logged"}</span>
                        <span><i class="fas fa-percentage"></i> Body Fat: {f"{entry[2]}%" if entry[2] is not None else "Not logged"}</span>
                        <span><i class="fas fa-bed"></i> Sleep: {f"{entry[3]}h" if entry[3] is not None else "Not logged"}</span>
                        <span><i class="fas fa-tint"></i> Water: {f"{entry[4]}L" if entry[4] is not None else "Not logged"}</span>
                    </div>
                    {f'<p style="margin-top: 0.8rem;"><i class="fas fa-utensils"></i> <strong>Meals:</strong> {entry[5]}</p>' if entry[5] else ''}
                    {f'<p style="margin-top: 0.5rem;"><i class="fas fa-dumbbell"></i> <strong>Workouts:</strong> {entry[6]}</p>' if entry[6] else ''}
                </div>
                '''
        else:
            entries_html = '<p style="text-align: center; color: var(--text-secondary); font-style: italic;">No progress entries yet. Start logging today!</p>'

        content = f'''
        <div class="card">
            <h1><i class="fas fa-chart-line"></i> Track Your Daily Progress</h1>
            <p style="margin-bottom: 2rem; color: var(--text-secondary);">
                Consistency is key to achieving your fitness goals. Log your daily metrics below.
            </p>
            
            <form method="POST" style="margin-bottom: 3rem;">
                <div class="form-group">
                    <label for="date"><i class="fas fa-calendar"></i> Date:</label>
                    <input id="date" type="date" name="date" required value="{datetime.now().date()}"
                           max="{datetime.now().date()}" />
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="weight"><i class="fas fa-weight"></i> Weight (kg):</label>
                        <input id="weight" type="number" step="0.1" name="weight" min="30" max="500" 
                               placeholder="70.5" />
                    </div>
                    <div class="form-group">
                        <label for="body_fat"><i class="fas fa-percentage"></i> Body Fat (%):</label>
                        <input id="body_fat" type="number" step="0.1" name="body_fat" min="5" max="50" 
                               placeholder="15.0" />
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="sleep"><i class="fas fa-bed"></i> Sleep (hours):</label>
                        <input id="sleep" type="number" step="0.1" name="sleep" min="0" max="24" 
                               placeholder="8.0" />
                    </div>
                    <div class="form-group">
                        <label for="water"><i class="fas fa-tint"></i> Water Intake (liters):</label>
                        <input id="water" type="number" step="0.1" name="water" min="0" max="10" 
                               placeholder="2.5" />
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="meals"><i class="fas fa-utensils"></i> Meals (optional description):</label>
                    <textarea id="meals" name="meals" rows="3" 
                              placeholder="Describe what you ate today... (optional)"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="workouts"><i class="fas fa-dumbbell"></i> Workouts (optional description):</label>
                    <textarea id="workouts" name="workouts" rows="3" 
                              placeholder="Describe your workout routine... (optional)"></textarea>
                </div>
                
                <button type="submit" class="btn" style="width: 100%;">
                    <i class="fas fa-save"></i>
                    Save Today's Progress
                </button>
            </form>

            <h2><i class="fas fa-history"></i> Recent Progress Entries</h2>
            <div class="progress-entries">
                {entries_html}
            </div>

            <div class="flex mt-2">
                <a href="/progress_chart" class="btn">
                    <i class="fas fa-chart-area"></i>
                    View Progress Charts
                </a>
                <a href="/export_progress" class="btn btn-secondary">
                    <i class="fas fa-download"></i>
                    Export CSV
                </a>
            </div>
        </div>
        '''
        
    except Exception as e:
        logger.error(f"Progress page error: {e}")
        flash('Error loading progress page. Please try again.')
        return redirect(url_for('dashboard'))
        
    return render_template_string(BASE_TEMPLATE, content=content, user_logged_in=True, flash_messages=get_flashed_messages())

@app.route('/progress_chart')
def progress_chart():
    if 'user_id' not in session:
        flash('Please login to view your progress charts')
        return redirect(url_for('login'))

    try:
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute('''SELECT date, weight, body_fat, sleep, water, meals, workouts FROM progress 
                     WHERE user_id = ? ORDER BY date ASC''', (session['user_id'],))
        data = c.fetchall()
        conn.close()

        if not data:
            flash('No progress data found. Start logging your progress first!')
            return redirect(url_for('progress'))

        # Prepare data for charts
        dates = [row[0] for row in data]
        weights = [row[1] if row[1] is not None else None for row in data]
        body_fats = [row[2] if row[2] is not None else None for row in data]
        sleep_data = [row[3] if row[3] is not None else None for row in data]
        water_data = [row[4] if row[4] is not None else None for row in data]

        # Count days with meals and workouts logged
        meals_freq = [1 if row[5] and row[5].strip() else 0 for row in data]
        workouts_freq = [1 if row[6] and row[6].strip() else 0 for row in data]

        # Convert None values to null for JavaScript
        weights_js = ['null' if w is None else w for w in weights]
        body_fats_js = ['null' if bf is None else bf for bf in body_fats]
        sleep_js = ['null' if s is None else s for s in sleep_data]
        water_js = ['null' if w is None else w for w in water_data]

        content = f'''
        <div class="card">
            <h1><i class="fas fa-chart-area"></i> Your Progress Analytics</h1>
            <p style="margin-bottom: 2rem; color: var(--text-secondary);">
                Visualize your wellness journey over time
            </p>
            
            <div class="chart-container">
                <canvas id="weightChart"></canvas>
            </div>
            
            <div class="chart-container">
                <canvas id="bodyCompositionChart"></canvas>
            </div>
            
            <div class="chart-container">
                <canvas id="lifestyleChart"></canvas>
            </div>
            
            <div class="chart-container">
                <canvas id="frequencyChart"></canvas>
            </div>
            
            <div class="flex mt-2">
                <a href="/progress" class="btn">
                    <i class="fas fa-arrow-left"></i>
                    Back to Progress
                </a>
                <a href="/export_progress" class="btn btn-secondary">
                    <i class="fas fa-download"></i>
                    Export Data
                </a>
            </div>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
        <script>
            const dates = {dates};
            const weights = {weights_js};
            const bodyFats = {body_fats_js};
            const sleepData = {sleep_js};
            const waterData = {water_js};
            const mealsFreq = {meals_freq};
            const workoutsFreq = {workouts_freq};

            // Common chart options
            const commonOptions = {{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {{
                    legend: {{
                        position: 'top',
                        labels: {{
                            color: 'white',
                            padding: 20,
                            usePointStyle: true
                        }}
                    }}
                }},
                scales: {{
                    x: {{
                        ticks: {{
                            color: 'rgba(255,255,255,0.8)',
                            maxRotation: 45
                        }},
                        grid: {{
                            color: 'rgba(255,255,255,0.1)'
                        }}
                    }},
                    y: {{
                        ticks: {{
                            color: 'rgba(255,255,255,0.8)'
                        }},
                        grid: {{
                            color: 'rgba(255,255,255,0.1)'
                        }}
                    }}
                }}
            }};

            // Weight Chart
            const ctx1 = document.getElementById('weightChart').getContext('2d');
            new Chart(ctx1, {{
                type: 'line',
                data: {{
                    labels: dates,
                    datasets: [{{
                        label: 'Weight (kg)',
                        data: weights,
                        borderColor: '#ff6b6b',
                        backgroundColor: 'rgba(255,107,107,0.1)',
                        fill: true,
                        tension: 0.4,
                        pointRadius: 6,
                        pointHoverRadius: 8,
                        pointBackgroundColor: '#ff6b6b',
                        pointBorderColor: 'white',
                        pointBorderWidth: 2
                    }}]
                }},
                options: {{
                    ...commonOptions,
                    plugins: {{
                        ...commonOptions.plugins,
                        title: {{
                            display: true,
                            text: 'Weight Progress Over Time',
                            color: 'white',
                            font: {{
                                size: 16,
                                weight: 'bold'
                            }}
                        }}
                    }}
                }}
            }});

            // Body Composition Chart
            if (bodyFats.some(bf => bf !== null)) {{
                const ctx2 = document.getElementById('bodyCompositionChart').getContext('2d');
                new Chart(ctx2, {{
                    type: 'line',
                    data: {{
                        labels: dates,
                        datasets: [{{
                            label: 'Body Fat (%)',
                            data: bodyFats,
                            borderColor: '#4caf50',
                            backgroundColor: 'rgba(76,175,80,0.1)',
                            fill: true,
                            tension: 0.4,
                            pointRadius: 6,
                            pointHoverRadius: 8,
                            pointBackgroundColor: '#4caf50',
                            pointBorderColor: 'white',
                            pointBorderWidth: 2
                        }}]
                    }},
                    options: {{
                        ...commonOptions,
                        plugins: {{
                            ...commonOptions.plugins,
                            title: {{
                                display: true,
                                text: 'Body Fat Percentage Progress',
                                color: 'white',
                                font: {{
                                    size: 16,
                                    weight: 'bold'
                                }}
                            }}
                        }}
                    }}
                }});
            }} else {{
                document.getElementById('bodyCompositionChart').parentElement.style.display = 'none';
            }}

            // Lifestyle Metrics Chart
            if (sleepData.some(s => s !== null) || waterData.some(w => w !== null)) {{
                const ctx3 = document.getElementById('lifestyleChart').getContext('2d');
                const datasets = [];
                
                if (sleepData.some(s => s !== null)) {{
                    datasets.push({{
                        label: 'Sleep (hours)',
                        data: sleepData,
                        borderColor: '#9c27b0',
                        backgroundColor: 'rgba(156,39,176,0.1)',
                        yAxisID: 'y'
                    }});
                }}
                
                if (waterData.some(w => w !== null)) {{
                    datasets.push({{
                        label: 'Water (liters)',
                        data: waterData,
                        borderColor: '#2196f3',
                        backgroundColor: 'rgba(33,150,243,0.1)',
                        yAxisID: 'y1'
                    }});
                }}
                
                new Chart(ctx3, {{
                    type: 'line',
                    data: {{
                        labels: dates,
                        datasets: datasets
                    }},
                    options: {{
                        ...commonOptions,
                        plugins: {{
                            ...commonOptions.plugins,
                            title: {{
                                display: true,
                                text: 'Lifestyle Metrics',
                                color: 'white',
                                font: {{
                                    size: 16,
                                    weight: 'bold'
                                }}
                            }}
                        }},
                        scales: {{
                            ...commonOptions.scales,
                            y1: {{
                                type: 'linear',
                                display: waterData.some(w => w !== null),
                                position: 'right',
                                ticks: {{
                                    color: 'rgba(255,255,255,0.8)'
                                }},
                                grid: {{
                                    drawOnChartArea: false
                                }}
                            }}
                        }}
                    }}
                }});
            }} else {{
                document.getElementById('lifestyleChart').parentElement.style.display = 'none';
            }}

            // Frequency Chart
            const ctx4 = document.getElementById('frequencyChart').getContext('2d');
            new Chart(ctx4, {{
                type: 'bar',
                data: {{
                    labels: dates,
                    datasets: [
                        {{
                            label: 'Meals Logged',
                            data: mealsFreq,
                            backgroundColor: 'rgba(76, 175, 80, 0.8)',
                            borderRadius: 4
                        }},
                        {{
                            label: 'Workouts Logged',
                            data: workoutsFreq,
                            backgroundColor: 'rgba(33, 150, 243, 0.8)',
                            borderRadius: 4
                        }}
                    ]
                }},
                options: {{
                    ...commonOptions,
                    plugins: {{
                        ...commonOptions.plugins,
                        title: {{
                            display: true,
                            text: 'Logging Consistency',
                            color: 'white',
                            font: {{
                                size: 16,
                                weight: 'bold'
                            }}
                        }},
                        tooltip: {{
                            callbacks: {{
                                label: function(context) {{
                                    return context.dataset.label + ': ' + (context.parsed.y === 1 ? 'Yes' : 'No');
                                }}
                            }}
                        }}
                    }},
                    scales: {{
                        ...commonOptions.scales,
                        y: {{
                            ...commonOptions.scales.y,
                            beginAtZero: true,
                            max: 1,
                            ticks: {{
                                ...commonOptions.scales.y.ticks,
                                stepSize: 1,
                                callback: function(value) {{
                                    return value === 1 ? 'Yes' : 'No';
                                }}
                            }}
                        }}
                    }}
                }}
            }});
        </script>
        '''
        
    except Exception as e:
        logger.error(f"Progress chart error: {e}")
        flash('Error loading progress charts. Please try again.')
        return redirect(url_for('progress'))
        
    return render_template_string(BASE_TEMPLATE, content=content, user_logged_in=True, flash_messages=get_flashed_messages())

@app.route('/export_progress')
def export_progress():
    if 'user_id' not in session:
        flash('Please login to export your data')
        return redirect(url_for('login'))

    try:
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute('''SELECT date, weight, body_fat, sleep, water, meals, workouts 
                     FROM progress WHERE user_id = ? ORDER BY date ASC''', (session['user_id'],))
        data = c.fetchall()
        conn.close()

        if not data:
            flash('No progress data to export!')
            return redirect(url_for('progress'))

        # Create CSV in memory
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['Date', 'Weight (kg)', 'Body Fat (%)', 'Sleep (hours)', 'Water (liters)', 'Meals', 'Workouts'])
        
        for row in data:
            # Handle None values in CSV
            csv_row = [
                row[0],  # date
                row[1] if row[1] is not None else '',  # weight
                row[2] if row[2] is not None else '',  # body_fat
                row[3] if row[3] is not None else '',  # sleep
                row[4] if row[4] is not None else '',  # water
                row[5] if row[5] else '',  # meals
                row[6] if row[6] else ''   # workouts
            ]
            writer.writerow(csv_row)

        output.seek(0)
        
        # Generate filename with current date
        filename = f'fitlife_progress_{datetime.now().strftime("%Y%m%d")}.csv'
        
        return send_file(
            io.BytesIO(output.getvalue().encode('utf-8')),
            mimetype='text/csv',
            as_attachment=True,
            download_name=filename
        )
        
    except Exception as e:
        logger.error(f"Export error: {e}")
        flash('Error exporting data. Please try again.')
        return redirect(url_for('progress'))

# API endpoint for dashboard stats
@app.route('/api/stats')
def api_stats():
    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401
        
    try:
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        
        # Get total entries
        c.execute('SELECT COUNT(*) FROM progress WHERE user_id = ?', (session['user_id'],))
        total_entries = c.fetchone()[0]
        
        # Get current streak
        c.execute('''SELECT date FROM progress WHERE user_id = ? ORDER BY date DESC''', (session['user_id'],))
        dates = [row[0] for row in c.fetchall()]
        
        streak = 0
        if dates:
            current_date = date.today()
            for d in dates:
                entry_date = datetime.strptime(d, '%Y-%m-%d').date()
                if entry_date == current_date - timedelta(days=streak):
                    streak += 1
                else:
                    break
        
        conn.close()
        
        return jsonify({
            'total_entries': total_entries,
            'current_streak': streak
        })
        
    except Exception as e:
        logger.error(f"Stats API error: {e}")
        return jsonify({'error': 'Internal server error'}), 500

# Error handlers
@app.errorhandler(404)
def not_found(error):
    content = '''
    <div class="card text-center" style="max-width: 600px; margin: 4rem auto;">
        <i class="fas fa-exclamation-triangle" style="font-size: 4rem; color: var(--accent-color); margin-bottom: 2rem;"></i>
        <h1>Page Not Found</h1>
        <p style="margin-bottom: 2rem;">The page you're looking for doesn't exist.</p>
        <a href="/dashboard" class="btn">
            <i class="fas fa-home"></i>
            Go to Dashboard
        </a>
    </div>
    '''
    return render_template_string(BASE_TEMPLATE, content=content, user_logged_in='user_id' in session, flash_messages=[]), 404

@app.errorhandler(500)
def internal_error(error):
    content = '''
    <div class="card text-center" style="max-width: 600px; margin: 4rem auto;">
        <i class="fas fa-exclamation-circle" style="font-size: 4rem; color: var(--error-color); margin-bottom: 2rem;"></i>
        <h1>Something Went Wrong</h1>
        <p style="margin-bottom: 2rem;">We're experiencing technical difficulties. Please try again.</p>
        <a href="/dashboard" class="btn">
            <i class="fas fa-home"></i>
            Go to Dashboard
        </a>
    </div>
    '''
    return render_template_string(BASE_TEMPLATE, content=content, user_logged_in='user_id' in session, flash_messages=[]), 500

# Additional utility route for updating profile
@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user_id' not in session:
        flash('Please login to view your profile')
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        try:
            # Update user profile
            age = int(request.form['age'])
            weight = float(request.form['weight'])
            height = float(request.form['height'])
            goal = request.form['goal']
            activity_level = request.form['activity_level']
            
            if not (13 <= age <= 120):
                flash('Age must be between 13 and 120')
                return redirect(url_for('profile'))
            
            if not (30 <= weight <= 500):
                flash('Weight must be between 30 and 500 kg')
                return redirect(url_for('profile'))
            
            if not (100 <= height <= 250):
                flash('Height must be between 100 and 250 cm')
                return redirect(url_for('profile'))
            
            conn = sqlite3.connect('users.db')
            c = conn.cursor()
            c.execute('''UPDATE users SET age = ?, weight = ?, height = ?, goal = ?, activity_level = ? 
                         WHERE id = ?''',
                      (age, weight, height, goal, activity_level, session['user_id']))
            conn.commit()
            conn.close()
            
            flash('Profile updated successfully!')
            return redirect(url_for('dashboard'))
            
        except ValueError:
            flash('Please enter valid numeric values')
        except Exception as e:
            logger.error(f"Profile update error: {e}")
            flash('Error updating profile. Please try again.')
        finally:
            if 'conn' in locals():
                conn.close()
    
    # GET: show current profile
    try:
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],))
        user = c.fetchone()
        conn.close()
        
        if not user:
            session.clear()
            flash('User not found. Please login again.')
            return redirect(url_for('login'))

        content = f'''
        <div class="card" style="max-width: 700px; margin: 0 auto;">
            <h1><i class="fas fa-user-edit"></i> Update Your Profile</h1>
            <p style="margin-bottom: 2rem; color: var(--text-secondary);">
                Keep your information current for the best personalized experience
            </p>
            
            <form method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label for="age"><i class="fas fa-birthday-cake"></i> Age:</label>
                        <input id="age" type="number" name="age" min="13" max="120" required value="{user[4]}" />
                    </div>
                    <div class="form-group">
                        <label for="weight"><i class="fas fa-weight"></i> Weight (kg):</label>
                        <input id="weight" type="number" step="0.1" name="weight" min="30" max="500" required value="{user[5]}" />
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="height"><i class="fas fa-ruler-vertical"></i> Height (cm):</label>
                    <input id="height" type="number" name="height" min="100" max="250" required value="{user[6]}" />
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="goal"><i class="fas fa-bullseye"></i> Goal:</label>
                        <select id="goal" name="goal" required>
                            <option value="weight_loss" {"selected" if user[7] == "weight_loss" else ""}>🔥 Weight Loss</option>
                            <option value="muscle_gain" {"selected" if user[7] == "muscle_gain" else ""}>💪 Muscle Gain</option>
                            <option value="maintenance" {"selected" if user[7] == "maintenance" else ""}>⚖️ Maintenance</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="activity_level"><i class="fas fa-running"></i> Activity Level:</label>
                        <select id="activity_level" name="activity_level" required>
                            <option value="beginner" {"selected" if user[8] == "beginner" else ""}>🌱 Beginner</option>
                            <option value="intermediate" {"selected" if user[8] == "intermediate" else ""}>🚀 Intermediate</option>
                            <option value="advanced" {"selected" if user[8] == "advanced" else ""}>⭐ Advanced</option>
                        </select>
                    </div>
                </div>
                
                <div class="flex" style="justify-content: center; margin-top: 2rem;">
                    <button type="submit" class="btn">
                        <i class="fas fa-save"></i>
                        Update Profile
                    </button>
                    <a href="/dashboard" class="btn btn-secondary">
                        <i class="fas fa-times"></i>
                        Cancel
                    </a>
                </div>
            </form>
        </div>
        '''
        
    except Exception as e:
        logger.error(f"Profile page error: {e}")
        flash('Error loading profile. Please try again.')
        return redirect(url_for('dashboard'))
        
    return render_template_string(BASE_TEMPLATE, content=content, user_logged_in=True, flash_messages=get_flashed_messages())

# Enhanced main execution
if __name__ == '__main__':
    try:
        init_db()
        logger.info("Starting FitLife application...")
        app.run(debug=True, host='0.0.0.0', port=5000)
    except Exception as e:
        logger.error(f"Failed to start application: {e}")
        print(f"Error starting FitLife: {e}")