<?php
require_once 'includes/config.php';
session_start();

$action = $_GET['action'] ?? 'login';

if ($action == 'logout') {
    session_destroy();
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';
    $mode = $_POST['mode'] ?? 'login';

    if ($mode == 'register') {
        $email = $_POST['email'] ?? '';
        $hashed = password_hash($pass, PASSWORD_DEFAULT);
        try {
            $stmt = $pdo->prepare("INSERT INTO users (username, password, email) VALUES (?, ?, ?)");
            $stmt->execute([$user, $hashed, $email]);
            $user_id = $pdo->lastInsertId();
            
            // Initialize metrics
            $stmt = $pdo->prepare("INSERT INTO user_metrics (user_id) VALUES (?)");
            $stmt->execute([$user_id]);
            
            $_SESSION['user_id'] = $user_id;
            $_SESSION['username'] = $user;
            header('Location: index.php');
            exit;
        } catch (PDOException $e) {
            $error = "User already exists or email taken.";
        }
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$user]);
        $row = $stmt->fetch();
        if ($row && password_verify($pass, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            header('Location: index.php');
            exit;
        } else {
            $error = "Invalid credentials.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AUTH | TITAN GYM</title>
    <link rel="stylesheet" href="assets/css/titan.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="auth-wrapper">

    <div class="glass-panel auth-card">
        <div style="text-align: center; margin-bottom: 40px;">
            <div class="logo">TITAN<span>GYM</span></div>
            <p style="color: var(--text-dim); margin-top: 10px;" id="auth-subtitle">Welcome to the Elite Front.</p>
        </div>

        <?php if ($error): ?>
            <div style="background: rgba(255, 45, 85, 0.1); border: 1px solid var(--accent); color: var(--accent); padding: 15px; border-radius: 12px; margin-bottom: 25px; font-size: 0.9rem;">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="mode" id="auth-mode" value="login">
            
            <label class="stat-label">Codename / Username</label>
            <input type="text" name="username" class="auth-input" required placeholder="User-X">

            <div id="email-group" style="display: none;">
                <label class="stat-label">Neural Network / Email</label>
                <input type="email" name="email" class="auth-input" placeholder="user@frontier.net">
            </div>

            <label class="stat-label">Passkey</label>
            <input type="password" name="password" class="auth-input" required placeholder="••••••••">

            <button type="submit" class="btn-primary" style="width: 100%; justify-content: center; margin-top: 10px;" id="auth-btn">Authorize</button>
        </form>

        <div style="text-align: center; margin-top: 30px; font-size: 0.9rem;">
            <a href="#" style="color: var(--text-dim); text-decoration: none;" id="toggle-auth">New to the Frontier? <span style="color: var(--primary);">Enroll Here</span></a>
        </div>
    </div>

    <script>
        const modeInput = document.getElementById('auth-mode');
        const emailGroup = document.getElementById('email-group');
        const btn = document.getElementById('auth-btn');
        const subtitle = document.getElementById('auth-subtitle');
        const toggle = document.getElementById('toggle-auth');

        toggle.addEventListener('click', (e) => {
            e.preventDefault();
            if (modeInput.value === 'login') {
                modeInput.value = 'register';
                emailGroup.style.display = 'block';
                btn.innerText = 'Establish Connection';
                subtitle.innerText = 'Join the Titan Core.';
                toggle.innerHTML = 'Already a Titan? <span style="color: var(--primary);">Access System</span>';
            } else {
                modeInput.value = 'login';
                emailGroup.style.display = 'none';
                btn.innerText = 'Authorize';
                subtitle.innerText = 'Welcome back to the Frontier.';
                toggle.innerHTML = 'New to the Frontier? <span style="color: var(--primary);">Enroll Here</span>';
            }
        });
    </script>
</body>
</html>
