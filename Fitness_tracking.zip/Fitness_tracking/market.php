<?php
require_once 'includes/config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: auth.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Get user credits
$stmt = $pdo->prepare("SELECT neural_credits FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$credits = $stmt->fetchColumn();

// Get market items
$stmt = $pdo->query("SELECT * FROM marketplace_items");
$items = $stmt->fetchAll();

// Get inventory
$stmt = $pdo->prepare("SELECT item_id FROM user_inventory WHERE user_id = ?");
$stmt->execute([$user_id]);
$inventory = $stmt->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MARKET | TITAN GYM</title>
    <link rel="stylesheet" href="assets/css/titan.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo">TITAN<span>GYM</span></div>
        <div class="nav-links">
            <a href="index.php">Lobby</a>
            <a href="frontier.php">Frontier</a>
            <a href="market.php" class="active">Market</a>
            <a href="classes.php">Classes</a>
            <a href="training.php">Training Matrix</a>
            <a href="tv.php">Titan TV</a>
            <a href="profile.php">Bio</a>
            <a href="logout.php">Signal Out</a>
        </div>
    </nav>

    <div class="titan-container">
        <header style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 40px; animation: fadeIn 0.8s ease-out;">
            <div>
                <h1 class="text-gradient" style="font-size: 3rem;">Cyber Marketplace</h1>
                <p style="color: var(--text-dim);">Exchange Neural Credits for elite gear and bio-enhancements.</p>
            </div>
            <div class="glass-panel" style="padding: 15px 25px; border-color: var(--primary);">
                <div style="font-size: 0.7rem; color: var(--text-dim); text-transform: uppercase;">Current Balance</div>
                <div style="font-size: 1.8rem; font-weight: 800; color: var(--primary);">$<?php echo number_format($credits); ?> <span style="font-size: 0.8rem;">NCR</span></div>
            </div>
        </header>

        <div class="titan-grid">
            <?php foreach($items as $item): 
                $is_owned = in_array($item['id'], $inventory);
            ?>
                <div class="glass-panel" style="grid-column: span 4; display: flex; flex-direction: column; gap: 15px; <?php echo $is_owned ? 'opacity: 0.7; border-color: var(--secondary);' : ''; ?>">
                    <div style="height: 180px; background: rgba(0,0,0,0.3); border-radius: 12px; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden;">
                        <img src="<?php echo $item['image_url']; ?>" style="width: 80px; height: 80px; filter: drop-shadow(0 0 10px var(--primary));">
                        <?php if($is_owned): ?>
                            <div style="position: absolute; top: 10px; right: 10px; background: var(--secondary); color: white; font-size: 0.6rem; padding: 4px 10px; border-radius: 10px; font-weight: 800;">OWNED</div>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
                            <h3 style="color: var(--primary);"><?php echo $item['name']; ?></h3>
                            <span style="font-size: 0.7rem; background: var(--glass); padding: 2px 8px; border-radius: 5px; border: 1px solid var(--glass-border); text-transform: uppercase;"><?php echo $item['category']; ?></span>
                        </div>
                        <p style="font-size: 0.85rem; color: var(--text-dim); line-height: 1.4;"><?php echo $item['description']; ?></p>
                    </div>
                    
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: auto;">
                        <span style="font-size: 1.2rem; font-weight: 800; color: var(--text-main);"><?php echo number_format($item['price']); ?> <span style="font-size: 0.7rem; color: var(--text-dim);">NCR</span></span>
                        <?php if($is_owned): ?>
                            <button class="btn-primary" style="background: var(--glass); color: var(--text-dim); cursor: default;" disabled>Acquired</button>
                        <?php else: ?>
                            <button class="btn-primary" style="font-size: 0.8rem;" onclick="buyItem(<?php echo $item['id']; ?>, <?php echo $item['price']; ?>)">Acquire</button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Inventory Section -->
        <section style="margin-top: 60px;">
            <h2 class="text-gradient" style="margin-bottom: 25px;">Personal Inventory</h2>
            <div class="titan-grid">
                <?php if(empty($inventory)): ?>
                    <div class="glass-panel" style="grid-column: span 12; text-align: center; color: var(--text-dim);">
                        Inventory empty. Complete training objectives to earn credits.
                    </div>
                <?php else: ?>
                    <?php 
                    $stmt = $pdo->prepare("SELECT i.* FROM marketplace_items i JOIN user_inventory ui ON i.id = ui.item_id WHERE ui.user_id = ?");
                    $stmt->execute([$user_id]);
                    $owned_items = $stmt->fetchAll();
                    foreach($owned_items as $oi): ?>
                        <div class="glass-panel" style="grid-column: span 2; display: flex; flex-direction: column; align-items: center; gap: 10px; text-align: center; padding: 15px;">
                            <img src="<?php echo $oi['image_url']; ?>" style="width: 40px; height: 40px; filter: grayscale(1) brightness(2);">
                            <div style="font-size: 0.7rem; font-weight: 700;"><?php echo $oi['name']; ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </section>
    </div>

    <script src="assets/js/titan.js"></script>
    <script>
        async function buyItem(id, price) {
            if(!confirm(`Confirm acquisition for ${price} Neural Credits?`)) return;

            const formData = new FormData();
            formData.append('action', 'buy_item');
            formData.append('item_id', id);

            try {
                const res = await fetch('api_titan.php', { method: 'POST', body: formData });
                const data = await res.json();
                if(data.status === 'success') {
                    alert("Aquisition complete. Gear synced to your bio-signature.");
                    location.reload();
                } else {
                    alert(data.message || "Acquisition failed.");
                }
            } catch(e) { alert("Network disruption. Transaction aborted."); }
        }
    </script>
</body>
</html>
