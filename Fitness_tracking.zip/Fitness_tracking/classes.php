<?php
require_once 'includes/config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: auth.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Get classes
$stmt = $pdo->query("SELECT * FROM gym_classes ORDER BY start_time ASC");
$classes = $stmt->fetchAll();

// Get enrollments for current user to show 'Enrolled' status
$stmt = $pdo->prepare("SELECT class_id FROM enrollments WHERE user_id = ?");
$stmt->execute([$user_id]);
$enrolled_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CLASSES | TITAN GYM</title>
    <link rel="stylesheet" href="assets/css/titan.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo">TITAN<span>GYM</span></div>
        <div class="nav-links">
            <a href="index.php">Lobby</a>
            <a href="frontier.php">Frontier</a>
            <a href="market.php">Market</a>
            <a href="classes.php" class="active">Classes</a>
            <a href="training.php">Training Matrix</a>
            <a href="tv.php">Titan TV</a>
            <a href="profile.php">Bio</a>
            <a href="logout.php">Signal Out</a>
        </div>
    </nav>

    <div class="titan-container">
        <header style="margin-bottom: 50px;">
            <h1 class="text-gradient" style="font-size: 3rem;">Class Schedule</h1>
            <p style="color: var(--text-dim);">Join high-intensity sectors led by elite trainers.</p>
        </header>

        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 30px;">
            <?php foreach($classes as $c): ?>
                <div class="glass-panel" style="padding: 0; display: flex; flex-direction: column;">
                    <div style="height: 200px; background: url('<?php echo $c['image_url']; ?>') center/cover;"></div>
                    <div style="padding: 25px; flex: 1;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <span style="font-size: 0.7rem; color: var(--primary); font-weight: 800; text-transform: uppercase;">Sector: <?php echo $c['category']; ?></span>
                            <span style="font-size: 0.7rem; color: var(--accent); font-weight: 800;"><?php echo $c['difficulty']; ?></span>
                        </div>
                        <h3 style="margin-bottom: 15px;"><?php echo $c['name']; ?></h3>
                        <p style="font-size: 0.9rem; color: var(--text-dim); margin-bottom: 20px;">Trainer: <strong style="color: white;"><?php echo $c['trainer']; ?></strong></p>
                        
                        <div style="display: flex; gap: 20px; font-size: 0.8rem; opacity: 0.7; margin-bottom: 25px;">
                            <span><i class="fa-solid fa-calendar"></i> <?php echo date('M d, H:i', strtotime($c['start_time'])); ?></span>
                            <span><i class="fa-solid fa-hourglass"></i> <?php echo $c['duration_mins']; ?> min</span>
                        </div>

                        <?php if (in_array($c['id'], $enrolled_ids)): ?>
                            <button class="btn-primary" style="width: 100%; filter: grayscale(1); cursor: default;">Enrolled</button>
                        <?php else: ?>
                            <button class="btn-primary" style="width: 100%;" onclick="enroll(<?php echo $c['id']; ?>)">Initialize Access</button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="assets/js/titan.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
</body>
</html>
