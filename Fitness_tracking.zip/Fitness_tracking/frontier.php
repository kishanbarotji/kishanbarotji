<?php
require_once 'includes/config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: auth.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Get feed from DB
$feed_stmt = $pdo->prepare("SELECT s.*, u.username FROM social_feed s JOIN users u ON s.user_id = u.id ORDER BY s.created_at DESC LIMIT 20");
$feed_stmt->execute();
$feed = $feed_stmt->fetchAll();

// Get squads
$squads_stmt = $pdo->query("SELECT * FROM squads LIMIT 5");
$squads = $squads_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FRONTIER | TITAN GYM</title>
    <link rel="stylesheet" href="assets/css/titan.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo">TITAN<span>GYM</span></div>
        <div class="nav-links">
            <a href="index.php">Lobby</a>
            <a href="frontier.php" class="active">Frontier</a>
            <a href="market.php">Market</a>
            <a href="classes.php">Classes</a>
            <a href="training.php">Training Matrix</a>
            <a href="tv.php">Titan TV</a>
            <a href="profile.php">Bio</a>
            <a href="logout.php">Signal Out</a>
        </div>
    </nav>

    <div class="titan-container">
        <header style="margin-bottom: 40px; animation: fadeIn 0.8s ease-out;">
            <h1 class="text-gradient" style="font-size: 3rem;">The Social Frontier</h1>
            <p style="color: var(--text-dim);">Neural connections and squad activity across the Titan network.</p>
        </header>

        <div class="titan-grid">
            <!-- Left: Sidebar (Squads) -->
            <div class="glass-panel" style="grid-column: span 3; height: fit-content;">
                <h3 style="margin-bottom: 20px; color: var(--primary);">Active Squads</h3>
                <?php foreach($squads as $squad): ?>
                    <div style="display: flex; gap: 15px; align-items: center; margin-bottom: 20px; padding: 10px; border-radius: 10px; background: rgba(255,255,255,0.02);">
                        <img src="<?php echo $squad['logo_url']; ?>" style="width: 40px; height: 40px; filter: hue-rotate(90deg);">
                        <div>
                            <div style="font-weight: 600; font-size: 0.9rem;"><?php echo $squad['name']; ?></div>
                            <div style="font-size: 0.7rem; color: var(--text-dim);"><?php echo $squad['total_xp']; ?> XP COLLECTED</div>
                        </div>
                    </div>
                <?php endforeach; ?>
                <button class="btn-primary" style="width: 100%; font-size: 0.7rem; justify-content: center;">Found New Squad</button>
            </div>

            <!-- Middle: Main Feed -->
            <div style="grid-column: span 6; display: flex; flex-direction: column; gap: 20px;">
                <div class="glass-panel" style="padding: 15px;">
                    <textarea id="post-input" placeholder="Broadcast a signal to the frontier..." style="width: 100%; background: transparent; border: none; color: white; outline: none; resize: none; min-height: 80px;"></textarea>
                    <div style="display: flex; justify-content: flex-end; margin-top: 10px;">
                        <button class="btn-primary" style="font-size: 0.7rem;" onclick="postSignal()">Transmit</button>
                    </div>
                </div>

                <div id="social-feed" style="display: flex; flex-direction: column; gap: 20px;">
                    <?php if (empty($feed)): ?>
                        <div class="glass-panel" style="text-align: center; color: var(--text-dim);">
                            <i class="fa-solid fa-satellite-dish" style="font-size: 2rem; margin-bottom: 10px;"></i>
                            <p>No signals detected in this sector.</p>
                        </div>
                    <?php endif; ?>

                    <?php foreach($feed as $entry): ?>
                        <div class="glass-panel" style="animation: fadeIn 0.5s ease-out;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                                <div style="display: flex; gap: 10px; align-items: center;">
                                    <div style="width: 35px; height: 35px; background: var(--secondary); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 0.8rem;">
                                        <?php echo strtoupper(substr($entry['username'], 0, 1)); ?>
                                    </div>
                                    <div>
                                        <div style="font-weight: 600; font-size: 0.9rem;"><?php echo $entry['username']; ?></div>
                                        <div style="font-size: 0.7rem; color: var(--text-dim);"><?php echo date('H:i', strtotime($entry['created_at'])); ?> SIGNAL ORIGIN</div>
                                    </div>
                                </div>
                                <?php if($entry['type'] === 'achievement'): ?>
                                    <span style="font-size: 0.6rem; background: var(--primary); color: black; padding: 2px 8px; border-radius: 10px; height: fit-content; font-weight: 800;">ACHIEVEMENT</span>
                                <?php endif; ?>
                            </div>
                            <p style="font-size: 0.95rem; line-height: 1.5; color: rgba(255,255,255,0.9);"><?php echo htmlspecialchars($entry['content']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Right: Stats / Pulse -->
            <div style="grid-column: span 3; display: flex; flex-direction: column; gap: 20px;">
                <div class="glass-panel">
                    <h3 style="margin-bottom: 20px; color: var(--secondary);">Titan Pulse</h3>
                    <div style="font-size: 0.8rem; color: var(--text-dim); margin-bottom: 15px;">
                        <span class="live-indicator"></span> 1,284 Titans Online
                    </div>
                    <div style="display: flex; flex-direction: column; gap: 10px;">
                        <div style="display: flex; justify-content: space-between; font-size: 0.75rem;">
                            <span>Global Intensity</span>
                            <span style="color: var(--primary);">88%</span>
                        </div>
                        <div style="height: 4px; background: rgba(255,255,255,0.05); border-radius: 2px;">
                            <div style="width: 88%; height: 100%; background: var(--primary); border-radius: 2px;"></div>
                        </div>
                    </div>
                </div>

                <div class="glass-panel">
                    <h3 style="margin-bottom: 15px; color: var(--accent);">Trending Sectors</h3>
                    <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                        <span style="font-size: 0.7rem; background: var(--glass); padding: 5px 12px; border-radius: 20px; border: 1px solid var(--glass-border);">#HypertrophyPlan</span>
                        <span style="font-size: 0.7rem; background: var(--glass); padding: 5px 12px; border-radius: 20px; border: 1px solid var(--glass-border);">#JaxVoltCardio</span>
                        <span style="font-size: 0.7rem; background: var(--glass); padding: 5px 12px; border-radius: 20px; border: 1px solid var(--glass-border);">#NeuralCredits</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/titan.js"></script>
    <script>
        async function postSignal() {
            const input = document.getElementById('post-input');
            const content = input.value.trim();
            if(!content) return;

            const formData = new FormData();
            formData.append('action', 'post_signal');
            formData.append('content', content);

            try {
                // Post signal action needs to be added to api_titan.php
                const res = await fetch('api_titan.php', { method: 'POST', body: formData });
                location.reload();
            } catch(e) { alert("Transmission failed."); }
        }
    </script>
</body>
</html>
