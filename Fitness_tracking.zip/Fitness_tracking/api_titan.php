<?php
require_once 'includes/config.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized Access']);
    exit;
}

$user_id = $_SESSION['user_id'];
$action = $_REQUEST['action'] ?? '';

if ($action === 'log_vital') {
    $type = $_POST['type'] ?? 'General';
    $val = floatval($_POST['value'] ?? 0);
    
    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, log_type, val_primary, details) VALUES (?, 'vital', ?, ?)");
    $stmt->execute([$user_id, $val, $type]);
    
    echo json_encode(['status' => 'success']);
    exit;
}

if ($action === 'enroll') {
    $class_id = intval($_POST['class_id'] ?? 0);
    
    try {
        $stmt = $pdo->prepare("INSERT INTO enrollments (user_id, class_id) VALUES (?, ?)");
        $stmt->execute([$user_id, $class_id]);
        echo json_encode(['status' => 'success']);
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Already enrolled in this sector.']);
    }
    exit;
}

if ($action === 'log_exercise') {
    $plan_id = intval($_POST['plan_id'] ?? 0);
    $ex_name = $_POST['exercise'] ?? '';
    
    // Store in activity_logs
    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, log_type, val_primary, details) VALUES (?, 'exercise', 1, ?)");
    $stmt->execute([$user_id, $ex_name]);
    
    // Award Neural Credits
    $credits_awarded = 100;
    $stmt = $pdo->prepare("UPDATE users SET neural_credits = neural_credits + ? WHERE id = ?");
    $stmt->execute([$credits_awarded, $user_id]);
    
    // Add to social feed as achievement
    $stmt = $pdo->prepare("INSERT INTO social_feed (user_id, content, type) VALUES (?, ?, 'achievement')");
    $stmt->execute([$user_id, "Completed objective: $ex_name. Gained $credits_awarded Neural Credits."]);
    
    echo json_encode(['status' => 'success', 'credits' => $credits_awarded]);
    exit;
}

if ($action === 'get_market') {
    $stmt = $pdo->query("SELECT * FROM marketplace_items");
    echo json_encode(['status' => 'success', 'items' => $stmt->fetchAll()]);
    exit;
}

if ($action === 'buy_item') {
    $item_id = intval($_POST['item_id'] ?? 0);
    
    // Check price
    $stmt = $pdo->prepare("SELECT price FROM marketplace_items WHERE id = ?");
    $stmt->execute([$item_id]);
    $item = $stmt->fetch();
    
    if (!$item) { echo json_encode(['status' => 'error', 'message' => 'Item not found']); exit; }
    
    $stmt = $pdo->prepare("SELECT neural_credits FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user_credits = $stmt->fetchColumn();
    
    if ($user_credits < $item['price']) {
        echo json_encode(['status' => 'error', 'message' => 'Insufficient Neural Credits']);
        exit;
    }
    
    // Transaction
    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("UPDATE users SET neural_credits = neural_credits - ? WHERE id = ?");
        $stmt->execute([$item['price'], $user_id]);
        
        $stmt = $pdo->prepare("INSERT INTO user_inventory (user_id, item_id) VALUES (?, ?)");
        $stmt->execute([$user_id, $item_id]);
        $pdo->commit();
        
        echo json_encode(['status' => 'success']);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'message' => 'Transaction failed']);
    }
    exit;
}

if ($action === 'save_protocol') {
    $name = $_POST['name'] ?? 'Custom Protocol';
    $ex_json = $_POST['exercises'] ?? '[]';
    
    // Deactivate old plans for user
    $stmt = $pdo->prepare("UPDATE workout_plans SET is_active = 0 WHERE user_id = ?");
    $stmt->execute([$user_id]);
    
    // Insert new plan
    $stmt = $pdo->prepare("INSERT INTO workout_plans (user_id, plan_name, plan_data) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $name, $ex_json]);
    
    echo json_encode(['status' => 'success']);
    exit;
}
if ($action === 'post_signal') {
    $content = $_POST['content'] ?? '';
    if (!empty($content)) {
        $stmt = $pdo->prepare("INSERT INTO social_feed (user_id, content, type) VALUES (?, ?, 'post')");
        $stmt->execute([$user_id, $content]);
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Empty transmission.']);
    }
    exit;
}

if ($action === 'ai_query') {
    $query = strtolower($_GET['q'] ?? '');
    
    // Fetch metrics for context
    $stmt = $pdo->prepare("SELECT * FROM user_metrics WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $m = $stmt->fetch();
    
    $goal = $m['fitness_goal'] ?? 'general fitness';
    $weight = $m['weight'] ?? 70;
    
    $response = "";
    
    if (strpos($query, 'macro') !== false || strpos($query, 'protein') !== false || strpos($query, 'fat') !== false) {
        $protein = $weight * 2;
        $fat = $weight * 0.8;
        $carbs = ($goal === 'lose weight') ? $weight * 2 : $weight * 4;
        $response = "Macro Protocol Initiated: For your weight ($weight kg), aim for: Protein: {$protein}g | Fat: {$fat}g | Carbs: {$carbs}g. Optimizing nutrient timing for maximum hypertrophy.";
    } elseif (strpos($query, 'plan') !== false || strpos($query, 'workout') !== false) {
        $response = "Analyzing biometrics... Your objective is '$goal'. For a current weight of $weight kg, I recommend maximizing fast-twitch fiber activation. I've updated your Training Matrix with heavy compound movements.";
    } elseif (strpos($query, 'status') !== false || strpos($query, 'how am i') !== false) {
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM activity_logs WHERE user_id = ? AND log_type = 'exercise' AND DATE(log_date) = CURDATE()");
        $stmt->execute([$user_id]);
        $done = $stmt->fetch()['count'];
        $response = "You have completed $done objectives today. Vitals are within nominal patterns. System status: OPTIMAL.";
    } elseif (strpos($query, 'credits') !== false || strpos($query, 'money') !== false) {
        $stmt = $pdo->prepare("SELECT neural_credits FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $c = $stmt->fetchColumn();
        $response = "You currently hold $c Neural Credits. You can trade these in the Marketplace for elite gear or profile enhancements.";
    } else {
        $response = "I am TITAN AI. I monitor your evolution. Ask about macros, your plan, or neural status.";
    }
    
    echo json_encode(['status' => 'success', 'response' => $response]);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'Undefined Sector']);
