<?php
require_once 'includes/config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: auth.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $age = intval($_POST['age']);
    $height = floatval($_POST['height']);
    $weight = floatval($_POST['weight']);
    $goal = $_POST['goal'];
    $activity = $_POST['activity'];

    $stmt = $pdo->prepare("UPDATE user_metrics SET age = ?, height = ?, weight = ?, fitness_goal = ?, activity_level = ? WHERE user_id = ?");
    $stmt->execute([$age, $height, $weight, $goal, $activity, $user_id]);
    $success = true;
}

$stmt = $pdo->prepare("SELECT * FROM user_metrics WHERE user_id = ?");
$stmt->execute([$user_id]);
$metrics = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BIO | TITAN GYM</title>
    <link rel="stylesheet" href="assets/css/titan.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo">TITAN<span>GYM</span></div>
        <div class="nav-links">
            <a href="index.php">Lobby</a>
            <a href="frontier.php">Frontier</a>
            <a href="market.php">Market</a>
            <a href="classes.php">Classes</a>
            <a href="training.php">Training Matrix</a>
            <a href="tv.php">Titan TV</a>
            <a href="profile.php" class="active">Bio</a>
            <a href="logout.php">Signal Out</a>
        </div>
    </nav>

    <div class="titan-container" style="max-width: 800px;">
        <div class="glass-panel">
            <h2 style="margin-bottom: 30px;"><i class="fa-solid fa-dna" style="color: var(--primary);"></i> Biometric Specification</h2>
            
            <?php if ($success): ?>
                <div style="background: rgba(0, 255, 157, 0.1); color: var(--primary); padding: 15px; border-radius: 12px; margin-bottom: 25px;">
                    Biometrics synchronized with Titan Core.
                </div>
            <?php endif; ?>

            <form method="POST">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div>
                        <label class="stat-label">Biological Age</label>
                        <input type="number" name="age" class="auth-input" value="<?php echo $metrics['age'] ?? ''; ?>" required>
                    </div>
                    <div>
                        <label class="stat-label">Fitness Objective</label>
                        <input type="text" name="goal" class="auth-input" placeholder="e.g. Mass Gain, Shred" value="<?php echo $metrics['fitness_goal'] ?? ''; ?>" required>
                    </div>
                    <div>
                        <label class="stat-label">Height (cm)</label>
                        <input type="number" step="0.1" name="height" class="auth-input" value="<?php echo $metrics['height'] ?? ''; ?>" required>
                    </div>
                    <div>
                        <label class="stat-label">Body Weight (kg)</label>
                        <input type="number" step="0.1" name="weight" class="auth-input" value="<?php echo $metrics['weight'] ?? ''; ?>" required>
                    </div>
                    <div style="grid-column: span 2;">
                        <label class="stat-label">Activity Level</label>
                        <select name="activity" class="auth-input" style="appearance: none;">
                            <option value="sedentary">Sedentary (Matrix Slave)</option>
                            <option value="lightly_active" <?php echo ($metrics['activity_level'] ?? '') == 'lightly_active' ? 'selected' : ''; ?>>Lightly Active</option>
                            <option value="moderately_active" <?php echo ($metrics['activity_level'] ?? '') == 'moderately_active' ? 'selected' : ''; ?>>Moderately Active</option>
                            <option value="very_active" <?php echo ($metrics['activity_level'] ?? '') == 'very_active' ? 'selected' : ''; ?>>Very Active (Titan)</option>
                            <option value="athlete" <?php echo ($metrics['activity_level'] ?? '') == 'athlete' ? 'selected' : ''; ?>>Elite Athlete (God Mode)</option>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn-primary" style="width: 100%; justify-content: center; margin-top: 30px;">Update Titan Bio-Signature</button>
            </form>
        </div>
    </div>

    <script src="assets/js/titan.js"></script>
</body>
</html>
