<?php
require_once 'includes/config.php';
session_start();

$is_logged_in = isset($_SESSION['user_id']);
$user_id = $is_logged_in ? $_SESSION['user_id'] : null;
$username = $is_logged_in ? $_SESSION['username'] : '';

// Fetch dynamic data if logged in
$stats = [
    'calories' => 0,
    'steps' => 0,
    'heart_rate' => '--',
    'active_minutes' => 0
];

if ($is_logged_in) {
    // Fetch latest vitals/activity
    $stmt = $pdo->prepare("SELECT * FROM activity_logs WHERE user_id = ? AND DATE(log_date) = CURDATE() ORDER BY log_date DESC");
    $stmt->execute([$user_id]);
    $logs = $stmt->fetchAll();
    
    foreach($logs as $log) {
        if ($log['log_type'] == 'exercise') $stats['calories'] += $log['val_primary'];
        if ($log['log_type'] == 'vital' && $log['details'] == 'Heart Rate') $stats['heart_rate'] = round($log['val_primary']);
    }

    // Fetch enrolled classes
    $stmt = $pdo->prepare("SELECT gc.* FROM gym_classes gc JOIN enrollments e ON gc.id = e.class_id WHERE e.user_id = ?");
    $stmt->execute([$user_id]);
    $my_classes = $stmt->fetchAll();
}

$all_classes_stmt = $pdo->query("SELECT * FROM gym_classes WHERE start_time > NOW() LIMIT 4");
$available_classes = $all_classes_stmt->fetchAll();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TITAN | Virtual Elite Gym</title>
    <link rel="stylesheet" href="assets/css/titan.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo">TITAN<span>GYM</span></div>
        <div class="nav-links">
            <a href="index.php" class="active">Lobby</a>
            <a href="frontier.php">Frontier</a>
            <a href="market.php">Market</a>
            <a href="classes.php">Classes</a>
            <a href="training.php">Training Matrix</a>
            <a href="tv.php">Titan TV</a>
            <a href="profile.php">Bio</a>
            <a href="logout.php">Signal Out</a>
        </div>
    </nav>

    <div class="titan-container">
        <?php if (!$is_logged_in): ?>
            <!-- Landing Hero Section -->
            <section class="hero-section" style="text-align: center; padding: 100px 0;">
                <h1 style="font-size: 4.5rem; font-weight: 800; line-height: 1.1;">EVOLVE BEYOND<br><span class="text-gradient">LIMITS</span></h1>
                <p style="color: var(--text-dim); font-size: 1.2rem; margin: 30px auto; max-width: 600px;">
                    Experience the next generation of fitness. AI-driven personalization, elite virtual coaching, and a community of titans.
                </p>
                <div style="display: flex; gap: 20px; justify-content: center; margin-top: 40px;">
                    <button class="btn-primary" onclick="window.location.href='auth.php'">Enroll Now <i class="fa-solid fa-bolt"></i></button>
                    <button class="btn-primary" style="background: var(--glass); color: white; border: 1px solid var(--glass-border);">Virtual Tour</button>
                </div>
                
                <div class="glass-panel" style="margin-top: 80px; max-width: 1000px; margin-left: auto; margin-right: auto; height: 400px; position: relative; overflow: hidden;">
                    <img src="https://images.unsplash.com/photo-1593079831268-3e4b3e8e7887?w=1200" style="width: 100%; height: 100%; object-fit: cover; opacity: 0.4;">
                    <div style="position: absolute; bottom: 40px; left: 40px; text-align: left;">
                        <span class="live-indicator"></span> <strong>LIVE NOW:</strong> Cyber Cardio Burn with Jax Volt
                    </div>
                </div>
            </section>
        <?php else: ?>
            <!-- Dashboard Section -->
            <header style="margin-bottom: 40px; animation: fadeIn 0.5s ease-out;">
                <h2>Welcome Back, <span class="text-gradient"><?php echo htmlspecialchars($username); ?></span></h2>
                <p style="color: var(--text-dim);">Your performance metrics are trending upward. Ready for Phase 2?</p>
            </header>

            <div class="titan-grid">
                <!-- Vitals Row -->
                <div class="glass-panel stat-card">
                    <span class="stat-label">Heart Rate</span>
                    <div class="stat-value"><i class="fa-solid fa-heart-pulse" style="color: var(--accent); margin-right: 10px;"></i><span id="live-hr"><?php echo $stats['heart_rate']; ?></span> <small style="font-size: 1rem; opacity: 0.5;">BPM</small></div>
                    <div style="font-size: 0.75rem; color: var(--primary);">Real-time Sync Active</div>
                </div>
                <div class="glass-panel stat-card">
                    <span class="stat-label">Daily Burn</span>
                    <div class="stat-value"><?php echo number_format($stats['calories']); ?> <small style="font-size: 1rem; opacity: 0.5;">kcal</small></div>
                    <div style="font-size: 0.75rem; color: var(--text-dim);">Goal: 2,500 kcal</div>
                </div>
                <div class="glass-panel stat-card">
                    <span class="stat-label">Titan Tier</span>
                    <div class="stat-value">LEVEL 12</div>
                    <div style="font-size: 0.75rem; color: var(--text-dim);">Top 5% in Community</div>
                </div>
                <div class="glass-panel stat-card" style="border-color: var(--primary);">
                    <span class="stat-label">Neural Credits</span>
                    <?php 
                        $stmt = $pdo->prepare("SELECT neural_credits FROM users WHERE id = ?");
                        $stmt->execute([$user_id]);
                        $credits = $stmt->fetchColumn();
                    ?>
                    <div class="stat-value" style="color: var(--primary);">$<?php echo number_format($credits); ?></div>
                    <div style="font-size: 0.75rem; color: var(--primary);">Neural Economy: STABLE</div>
                </div>

                <!-- Main Content Row -->
                <div class="glass-panel" style="grid-column: span 8; height: 450px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                        <h3>Active Performance Analysis</h3>
                        <div style="display: flex; gap: 10px;">
                            <span style="font-size: 0.8rem; background: rgba(0,255,157,0.1); padding: 5px 12px; border-radius: 20px; color: var(--primary);">Weekly View</span>
                        </div>
                    </div>
                    <div id="chart-container" style="width: 100%; height: 320px; display: flex; align-items: flex-end; gap: 15px; padding: 20px 0;">
                        <?php 
                        // Fetch real weekly activity for chart
                        $weekly_activity = [];
                        for ($i = 6; $i >= 0; $i--) {
                            $date = date('Y-m-d', strtotime("-$i days"));
                            $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM activity_logs WHERE user_id = ? AND log_type = 'exercise' AND DATE(log_date) = ?");
                            $stmt->execute([$user_id, $date]);
                            $weekly_activity[] = [
                                'day' => date('D', strtotime($date)),
                                'count' => $stmt->fetch()['count']
                            ];
                        }

                        foreach($weekly_activity as $act): 
                            $h = min(100, ($act['count'] / 5) * 100); // Scale 5 exercises to 100% height
                            if ($h == 0) $h = 5; // Minimal visibility
                        ?>
                            <div style="flex: 1; background: linear-gradient(to top, var(--primary), var(--secondary)); height: <?php echo $h; ?>%; border-radius: 6px 6px 0 0; opacity: 0.7; position: relative;">
                                <div style="position: absolute; bottom: -25px; left: 50%; transform: translateX(-50%); font-size: 0.7rem; color: var(--text-dim);"><?php echo $act['day']; ?></div>
                                <div style="position: absolute; top: -20px; left: 50%; transform: translateX(-50%); font-size: 0.6rem; color: var(--primary);"><?php echo $act['count']; ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- AI Sidebar -->
                <div class="glass-panel" style="grid-column: span 4; display: flex; flex-direction: column;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                        <h3>Titan AI Assistant</h3>
                        <span style="font-size: 0.6rem; color: var(--primary); border: 1px solid var(--primary); padding: 2px 8px; border-radius: 10px;">SIGNAL: STABLE</span>
                    </div>
                    <div id="ai-chat" style="flex: 1; overflow-y: auto; font-size: 0.9rem; color: var(--text-dim); padding-right: 10px; min-height: 250px;">
                        <div style="margin-bottom: 15px; background: rgba(255,255,255,0.05); padding: 12px; border-radius: 12px; border-left: 2px solid var(--primary);">
                            <strong>TITAN:</strong> Bio-authentication successful. Systems are operational. How shall we optimize your biology today?
                        </div>
                    </div>
                    <div style="margin-top: 20px;">
                        <input type="text" id="ai-input" placeholder="Neural inquiry..." style="width: 100%; background: var(--bg-black); border: 1px solid var(--glass-border); padding: 12px; border-radius: 10px; color: white; outline: none;">
                    </div>
                </div>

                <!-- Classes Grid -->
                <div style="grid-column: span 12; margin-top: 50px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                        <h2 id="classes">Recommended Sessions</h2>
                        <a href="#" style="color: var(--primary); text-decoration: none; font-size: 0.9rem;">View All Classes <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 25px;">
                        <?php foreach($available_classes as $class): ?>
                            <div class="glass-panel" style="padding: 0; overflow: hidden;">
                                <div style="height: 150px; background: url('<?php echo $class['image_url']; ?>') center/cover;"></div>
                                <div style="padding: 20px;">
                                    <div style="font-size: 0.7rem; color: var(--primary); text-transform: uppercase; font-weight: 800; margin-bottom: 8px;"><?php echo $class['category']; ?></div>
                                    <h4 style="margin-bottom: 12px;"><?php echo $class['name']; ?></h4>
                                    <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.8rem; color: var(--text-dim);">
                                        <span><i class="fa-solid fa-clock"></i> <?php echo $class['duration_mins']; ?> min</span>
                                        <span><i class="fa-solid fa-bolt"></i> <?php echo $class['difficulty']; ?></span>
                                    </div>
                                    <button class="btn-primary" style="width: 100%; margin-top: 20px; font-size: 0.8rem; padding: 10px;" onclick="enroll(<?php echo $class['id']; ?>)">Join Class</button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="assets/js/titan.js"></script>
</body>
</html>
