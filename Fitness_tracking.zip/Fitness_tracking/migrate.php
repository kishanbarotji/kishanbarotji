<?php
require_once 'includes/config.php';

try {
    $sql = file_get_contents('database.sql');
    $pdo->exec($sql);
    echo "Database migrated successfully. Neural circuits operational.";
} catch (PDOException $e) {
    echo "Migration failure: " . $e->getMessage();
}
?>
