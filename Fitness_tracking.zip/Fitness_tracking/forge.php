<?php
require_once 'includes/config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: auth.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Mock exercises for the forge
$exercises = [
    'Push' => ['Bench Press', 'Overhead Press', 'Lateral Raises', 'Dips'],
    'Pull' => ['Deadlift', 'Pull-Ups', 'Barbell Rows', 'Face Pulls'],
    'Legs' => ['Squats', 'Leg Press', 'Lunges', 'Calf Raises'],
    'Cyber' => ['HIIT Burpees', 'Battle Ropes', 'Box Jumps', 'Sprint Intervals']
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>THE FORGE | TITAN GYM</title>
    <link rel="stylesheet" href="assets/css/titan.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .forge-item {
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 10px;
        }
        .forge-item:hover {
            border-color: var(--primary);
            background: rgba(0, 255, 157, 0.05);
        }
        .protocol-slot {
            min-height: 80px;
            border: 1.5px dashed var(--glass-border);
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 15px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        .tag-remove {
            margin-left: 8px;
            cursor: pointer;
            color: var(--accent);
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="logo">TITAN<span>GYM</span></div>
        <div class="nav-links">
            <a href="index.php">Lobby</a>
            <a href="frontier.php">Frontier</a>
            <a href="market.php">Market</a>
            <a href="classes.php">Classes</a>
            <a href="training.php">Training Matrix</a>
            <a href="tv.php">Titan TV</a>
            <a href="profile.php">Bio</a>
            <a href="logout.php">Signal Out</a>
        </div>
    </nav>

    <div class="titan-container">
        <header style="margin-bottom: 40px;">
            <h1 class="text-gradient" style="font-size: 3rem;">The Titan Forge</h1>
            <p style="color: var(--text-dim);">Design your custom training protocols and sync them to your Bio-Link.</p>
        </header>

        <div class="titan-grid">
            <!-- Left: Exercise Library -->
            <div style="grid-column: span 4;">
                <div class="glass-panel" style="height: 600px; display: flex; flex-direction: column;">
                    <h3 style="margin-bottom: 20px;">Exercise Matrix</h3>
                    <div style="flex: 1; overflow-y: auto; padding-right: 10px;">
                        <?php foreach($exercises as $cat => $exs): ?>
                            <div style="margin-bottom: 20px;">
                                <div style="font-size: 0.7rem; color: var(--secondary); font-weight: 800; text-transform: uppercase; margin-bottom: 10px;"><?php echo $cat; ?></div>
                                <?php foreach($exs as $ex): ?>
                                    <div class="glass-panel forge-item" style="padding: 10px 15px; font-size: 0.9rem;" onclick="addToProtocol('<?php echo addslashes($ex); ?>')">
                                        <?php echo $ex; ?> <i class="fa-solid fa-plus" style="float: right; margin-top: 3px; font-size: 0.7rem;"></i>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Right: Protocol Builder -->
            <div style="grid-column: span 8;">
                <div class="glass-panel" style="height: 600px; display: flex; flex-direction: column;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                        <h3 style="color: var(--primary);">New Protocol Construction</h3>
                        <input type="text" id="protocol-name" placeholder="Protocol Name (e.g. ALPHA-1)" style="background: var(--bg-black); border: 1px solid var(--glass-border); color: white; padding: 8px 15px; border-radius: 8px; outline: none;">
                    </div>
                    
                    <div id="protocol-builder" style="flex: 1; overflow-y: auto;">
                        <div style="margin-bottom: 20px;">
                            <label style="font-size: 0.7rem; color: var(--text-dim); text-transform: uppercase;">Sequence Flow</label>
                            <div id="protocol-slots" class="protocol-slot">
                                <!-- Dynamic Items -->
                            </div>
                        </div>
                    </div>

                    <div style="border-top: 1px solid var(--glass-border); padding-top: 20px; display: flex; justify-content: space-between; align-items: center;">
                        <div style="color: var(--text-dim); font-size: 0.8rem;">
                            <i class="fa-solid fa-microchip"></i> Estimated Intensity: <span id="intensity-val" style="color: var(--primary);">0%</span>
                        </div>
                        <button class="btn-primary" onclick="forgeProtocol()">Forge Protocol</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/titan.js"></script>
    <script>
        let currentProtocol = [];

        function addToProtocol(ex) {
            currentProtocol.push(ex);
            renderProtocol();
        }

        function removeFromProtocol(index) {
            currentProtocol.splice(index, 1);
            renderProtocol();
        }

        function renderProtocol() {
            const container = document.getElementById('protocol-slots');
            container.innerHTML = '';
            
            if(currentProtocol.length === 0) {
                container.innerHTML = '<span style="color: var(--text-dim); font-size: 0.8rem; margin: auto;">Select exercises from the Matrix to begin assembly.</span>';
                document.getElementById('intensity-val').innerText = '0%';
                return;
            }

            currentProtocol.forEach((ex, i) => {
                const tag = document.createElement('div');
                tag.style.background = 'var(--secondary)';
                tag.style.color = 'white';
                tag.style.padding = '8px 15px';
                tag.style.borderRadius = '20px';
                tag.style.fontSize = '0.8rem';
                tag.style.fontWeight = '600';
                tag.innerHTML = `${ex} <i class="fa-solid fa-xmark tag-remove" onclick="removeFromProtocol(${i})"></i>`;
                container.appendChild(tag);
            });

            document.getElementById('intensity-val').innerText = Math.min(100, currentProtocol.length * 15) + '%';
        }

        async function forgeProtocol() {
            const name = document.getElementById('protocol-name').value;
            if(!name || currentProtocol.length === 0) {
                alert("Protocol signature incomplete.");
                return;
            }

            const formData = new FormData();
            formData.append('action', 'save_protocol');
            formData.append('name', name);
            formData.append('exercises', JSON.stringify(currentProtocol));

            try {
                // Save protocol action needs adding to api_titan.php
                const res = await fetch('api_titan.php', { method: 'POST', body: formData });
                alert("Protocol Forged. Synced to your Training Matrix.");
                window.location.href = 'training.php';
            } catch(e) { alert("Forge failure. Bio-link unstable."); }
        }

        renderProtocol();
    </script>
</body>
</html>
