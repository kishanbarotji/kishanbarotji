<?php
require_once 'includes/config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: auth.php');
    exit;
}

$user_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TITAN TV | VIRTUAL GYM</title>
    <link rel="stylesheet" href="assets/css/titan.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .channel-card {
            transition: all 0.3s;
            cursor: pointer;
            overflow: hidden;
        }
        .channel-card:hover {
            transform: translateY(-5px);
            border-color: var(--primary);
        }
        .live-tag {
            position: absolute;
            top: 15px;
            left: 15px;
            background: var(--accent);
            color: white;
            font-size: 0.6rem;
            padding: 3px 10px;
            border-radius: 5px;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 5px;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="logo">TITAN<span>GYM</span></div>
        <div class="nav-links">
            <a href="index.php">Lobby</a>
            <a href="frontier.php">Frontier</a>
            <a href="market.php">Market</a>
            <a href="classes.php">Classes</a>
            <a href="training.php">Training Matrix</a>
            <a href="tv.php" class="active">Titan TV</a>
            <a href="profile.php">Bio</a>
            <a href="logout.php">Signal Out</a>
        </div>
    </nav>

    <div class="titan-container">
        <!-- Hero: Main Spotlight Stream -->
        <section class="glass-panel" style="margin-bottom: 40px; padding: 0; position: relative; overflow: hidden; height: 500px; display: flex; align-items: flex-end;">
            <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(rgba(0,0,0,0), rgba(0,0,0,0.9)); z-index: 1;"></div>
            <img src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=1600" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover;">
            
            <div class="live-tag" style="z-index: 2; top: 30px; left: 30px; font-size: 0.8rem; padding: 5px 15px;">
                <span class="live-indicator" style="background: white; box-shadow: 0 0 10px white;"></span> LIVE NOW
            </div>

            <div style="position: relative; z-index: 2; padding: 50px; width: 100%;">
                <div style="font-size: 0.8rem; color: var(--primary); font-weight: 700; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 10px;">Titan Elite Series</div>
                <h1 style="font-size: 3.5rem; line-height: 1; margin-bottom: 20px;">HYPERTROPHY<br>DECODED</h1>
                <div style="display: flex; gap: 20px; align-items: center;">
                    <button class="btn-primary" onclick="alert('Neural link established. Streaming...')">Watch Live Stream</button>
                    <div style="color: var(--text-dim); font-size: 0.9rem;">
                        <i class="fa-solid fa-user-group"></i> 15,204 Titans Watching
                    </div>
                </div>
            </div>
        </section>

        <!-- Channel Grid -->
        <h2 class="text-gradient" style="margin-bottom: 25px;">Sectors & Streams</h2>
        <div class="titan-grid">
            <div class="glass-panel channel-card" style="grid-column: span 4; position: relative; padding: 0;">
                <div style="height: 160px; background: url('https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800') center/cover;"></div>
                <div class="live-tag">LIVE</div>
                <div style="padding: 20px;">
                    <h3 style="margin-bottom: 5px;">Zen Yoga Flow</h3>
                    <p style="font-size: 0.8rem; color: var(--text-dim);">with Sasha Luna • 2.4k viewers</p>
                </div>
            </div>

            <div class="glass-panel channel-card" style="grid-column: span 4; position: relative; padding: 0;">
                <div style="height: 160px; background: url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800') center/cover;"></div>
                <div style="position: absolute; top: 15px; left: 15px; background: var(--secondary); color: white; font-size: 0.6rem; padding: 3px 10px; border-radius: 5px; font-weight: 800;">ENCORE</div>
                <div style="padding: 20px;">
                    <h3 style="margin-bottom: 5px;">Power Protocol</h3>
                    <p style="font-size: 0.8rem; color: var(--text-dim);">with Marcus Thorne • Recorded</p>
                </div>
            </div>

            <div class="glass-panel channel-card" style="grid-column: span 4; position: relative; padding: 0;">
                <div style="height: 160px; background: url('https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=800') center/cover;"></div>
                <div style="position: absolute; top: 15px; left: 15px; background: rgba(255,255,255,0.1); color: white; font-size: 0.6rem; padding: 3px 10px; border-radius: 5px; font-weight: 800;">SCHEDULED</div>
                <div style="padding: 20px;">
                    <h3 style="margin-bottom: 5px;">Cardio Overdrive</h3>
                    <p style="font-size: 0.8rem; color: var(--text-dim);">Starts in 45:00 • Jax Volt</p>
                </div>
            </div>
        </div>

        <!-- On Demand -->
        <h2 class="text-gradient" style="margin-top: 60px; margin-bottom: 25px;">On-Demand Archives</h2>
        <div class="titan-grid" style="grid-template-columns: repeat(6, 1fr); gap: 15px;">
            <?php for($i=1; $i<=6; $i++): ?>
                <div class="glass-panel channel-card" style="grid-column: span 1; padding: 0;">
                    <div style="height: 100px; background: rgba(255,255,255,0.05); display: flex; align-items: center; justify-content: center;">
                        <i class="fa-solid fa-play" style="color: var(--primary);"></i>
                    </div>
                    <div style="padding: 10px; font-size: 0.7rem; font-weight: 600;">Sector <?php echo $i; ?> Archive</div>
                </div>
            <?php endfor; ?>
        </div>
    </div>

    <script src="assets/js/titan.js"></script>
</body>
</html>
