/**
 * TITAN GYM - Core Logic System v1.1
 */

// Live Heart Rate Simulation
function simulateVitals() {
    const hrElement = document.getElementById('live-hr');
    if (!hrElement) return;

    setInterval(() => {
        let currentHR = parseInt(hrElement.innerText) || 72;
        let change = Math.floor(Math.random() * 3) - 1;
        let newHR = Math.max(60, Math.min(180, currentHR + change));
        hrElement.innerText = newHR;

        if (Math.random() > 0.9) {
            updateVital('Heart Rate', newHR);
        }
    }, 2000);
}

async function updateVital(type, val) {
    const formData = new FormData();
    formData.append('action', 'log_vital');
    formData.append('type', type);
    formData.append('value', val);

    try {
        await fetch('api_titan.php', { method: 'POST', body: formData });
    } catch (e) { }
}

// AI Assistant Interactions
const aiInput = document.getElementById('ai-input');
const aiChat = document.getElementById('ai-chat');

if (aiInput) {
    aiInput.addEventListener('keypress', async (e) => {
        if (e.key === 'Enter' && aiInput.value.trim() !== '') {
            const msg = aiInput.value.trim();
            appendMessage('YOU', msg, false);
            aiInput.value = '';

            const typing = appendMessage('TITAN', '...', true);

            try {
                const response = await fetch('api_titan.php?action=ai_query&q=' + encodeURIComponent(msg));
                const data = await response.json();
                typing.remove();
                appendMessage('TITAN', data.response, true);
            } catch (err) {
                typing.remove();
                appendMessage('TITAN', "Connection disruption. Bio-link unstable.", true);
            }
        }
    });
}

function appendMessage(sender, text, isAI) {
    const div = document.createElement('div');
    div.style.marginBottom = '15px';
    div.style.padding = '12px';
    div.style.borderRadius = '12px';
    div.style.background = isAI ? 'rgba(255,255,255,0.05)' : 'rgba(0,255,157,0.05)';
    div.style.borderLeft = isAI ? '2px solid var(--primary)' : '2px solid var(--secondary)';
    div.innerHTML = `<strong>${sender}:</strong> ${text}`;
    if (aiChat) {
        aiChat.appendChild(div);
        aiChat.scrollTop = aiChat.scrollHeight;
    }
    return div;
}

// Class Enrollment
async function enroll(classId) {
    const formData = new FormData();
    formData.append('action', 'enroll');
    formData.append('class_id', classId);

    try {
        const res = await fetch('api_titan.php', { method: 'POST', body: formData });
        const data = await res.json();

        if (data.status === 'success') {
            alert("Objective Logged. Sector Cleared.");
            location.reload();
        } else {
            alert(data.message || "Enrollment failure.");
        }
    } catch (e) {
        alert("Fatal Error. Proxy Disruption.");
    }
}

// Mobile Menu Toggle
function setupMobileMenu() {
    const navbar = document.querySelector('.navbar');
    const navLinks = document.querySelector('.nav-links');
    if (!navbar || !navLinks) return;

    const toggle = document.createElement('div');
    toggle.className = 'mobile-toggle';
    toggle.innerHTML = '<i class="fa-solid fa-bars" style="color: var(--primary); font-size: 1.5rem; cursor: pointer;"></i>';

    // Responsive visibility logic
    const checkViewport = () => {
        if (window.innerWidth <= 768) {
            toggle.style.display = 'block';
        } else {
            toggle.style.display = 'none';
            navLinks.style.display = 'flex';
            navLinks.style.flexDirection = 'row';
            navLinks.style.position = 'static';
        }
    };

    navbar.insertBefore(toggle, navLinks);
    window.addEventListener('resize', checkViewport);
    checkViewport();

    toggle.onclick = () => {
        const isOpen = navLinks.style.display === 'flex' && navLinks.style.flexDirection === 'column';
        if (isOpen) {
            navLinks.style.display = 'none';
        } else {
            navLinks.style.display = 'flex';
            navLinks.style.flexDirection = 'column';
            navLinks.style.position = 'absolute';
            navLinks.style.top = '80px';
            navLinks.style.left = '0';
            navLinks.style.width = '100%';
            navLinks.style.background = 'rgba(5, 5, 7, 0.95)';
            navLinks.style.padding = '30px';
            navLinks.style.backdropFilter = 'blur(15px)';
            navLinks.style.borderBottom = '1px solid var(--glass-border)';
            navLinks.style.zIndex = '1000';
        }
    };
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    simulateVitals();
    setupMobileMenu();

    // Smooth Scrolling for anchors
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            if (href !== '#') {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    });
});
