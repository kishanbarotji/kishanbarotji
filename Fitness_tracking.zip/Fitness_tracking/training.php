<?php
require_once 'includes/config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: auth.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Mock training plan generation if none exists
$stmt = $pdo->prepare("SELECT * FROM workout_plans WHERE user_id = ? AND is_active = 1 LIMIT 1");
$stmt->execute([$user_id]);
$plan = $stmt->fetch();

if (!$plan) {
    // Generate a default plan
    $plan_data = [
        "Day 1: Upper Body Alpha" => ["Bench Press (4x10)", "Lat Pulldowns (3x12)", "Military Press (3x10)", "Bicep Curls (3x15)"],
        "Day 2: Lower Body Titan" => ["Squats (4x8)", "Deadlifts (3x8)", "Leg Press (3x12)", "Calf Raises (4x20)"],
        "Day 3: Rest & Repair" => ["Active Mobility Flow", "Hydration Focus"],
        "Day 4: Core Matrix" => ["Plank (3x60s)", "Russian Twists (3x20)", "Leg Raises (3x15)"]
    ];
    $stmt = $pdo->prepare("INSERT INTO workout_plans (user_id, plan_name, plan_data) VALUES (?, 'Titan Alpha Protocol', ?)");
    $stmt->execute([$user_id, json_encode($plan_data)]);
    header('Location: training.php');
    exit;
}

$plan_data = json_decode($plan['plan_data'], true);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TRAINING | TITAN GYM</title>
    <link rel="stylesheet" href="assets/css/titan.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

    <nav class="navbar">
        <div class="logo">TITAN<span>GYM</span></div>
        <div class="nav-links">
            <a href="index.php">Lobby</a>
            <a href="frontier.php">Frontier</a>
            <a href="market.php">Market</a>
            <a href="classes.php">Classes</a>
            <a href="training.php" class="active">Training Matrix</a>
            <a href="tv.php">Titan TV</a>
            <a href="profile.php">Bio</a>
            <a href="logout.php">Signal Out</a>
        </div>
    </nav>

    <div class="titan-container">
        <header style="margin-bottom: 50px;">
            <div style="display: flex; justify-content: space-between; align-items: flex-end;">
                <div>
                    <h1 class="text-gradient" style="font-size: 3rem;">Training Matrix</h1>
                    <p style="color: var(--text-dim);">AI Optimized Workflow: <?php echo $plan['plan_name']; ?></p>
                </div>
                <button class="btn-primary" style="font-size: 0.8rem; background: var(--glass); color: var(--primary); border: 1px solid var(--primary);" onclick="regeneratePlan()">Regenerate with AI</button>
            </div>
        </header>

        <div class="titan-grid">
            <?php foreach($plan_data as $day => $exercises): ?>
                <div class="glass-panel" style="grid-column: span 6;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid var(--glass-border); padding-bottom: 15px;">
                        <h3 style="color: var(--primary);"><?php echo $day; ?></h3>
                        <span style="font-size: 0.7rem; opacity: 0.6;">OBJ-LOGGED</span>
                    </div>
                    <?php foreach($exercises as $ex): ?>
                        <div class="exercise-row" id="ex-<?php echo md5($ex); ?>">
                            <span><?php echo $ex; ?></span>
                            <input type="checkbox" class="matrix-checkbox" onchange="logExercise('<?php echo addslashes($ex); ?>', <?php echo $plan['id']; ?>, this)">
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="assets/js/titan.js"></script>
    <script>
        async function logExercise(name, planId, checkbox) {
            const row = checkbox.closest('.exercise-row');
            if (checkbox.checked) {
                row.classList.add('completed');
                
                const formData = new FormData();
                formData.append('action', 'log_exercise');
                formData.append('plan_id', planId);
                formData.append('exercise', name);
                
                try {
                    await fetch('api_titan.php', { method: 'POST', body: formData });
                } catch(e) { console.error("Sync failed"); }
            } else {
                row.classList.remove('completed');
            }
        }

        function regeneratePlan() {
            const btn = event.target;
            btn.innerText = "Recalibrating...";
            setTimeout(() => {
                alert("AI has optimized your Matrix. New movements uploaded.");
                location.reload();
            }, 1500);
        }
    </script>
</body>
</html>
