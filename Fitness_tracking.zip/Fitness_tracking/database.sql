CREATE DATABASE IF NOT EXISTS fitness_db;
USE fitness_db;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE,
    neural_credits INT DEFAULT 1000, -- Starting credits
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User Biometrics & Context
CREATE TABLE IF NOT EXISTS user_metrics (
    user_id INT PRIMARY KEY,
    age INT,
    gender VARCHAR(20),
    height DECIMAL(5,2),
    weight DECIMAL(5,2),
    body_fat DECIMAL(4,2),
    activity_level ENUM('sedentary', 'lightly_active', 'moderately_active', 'very_active', 'athlete'),
    fitness_goal VARCHAR(100),
    medical_notes TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Social System: Friendships
CREATE TABLE IF NOT EXISTS friendships (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    friend_id INT,
    status ENUM('pending', 'accepted') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (friend_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Social System: Feed
CREATE TABLE IF NOT EXISTS social_feed (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    content TEXT,
    media_url VARCHAR(255),
    type ENUM('achievement', 'post', 'workout_sync') DEFAULT 'post',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Squad System
CREATE TABLE IF NOT EXISTS squads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    logo_url VARCHAR(255),
    total_xp INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS squad_members (
    squad_id INT,
    user_id INT,
    role ENUM('member', 'leader') DEFAULT 'member',
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (squad_id, user_id),
    FOREIGN KEY (squad_id) REFERENCES squads(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Marketplace System
CREATE TABLE IF NOT EXISTS marketplace_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price INT NOT NULL,
    category ENUM('gear', 'badge', 'boost') DEFAULT 'gear',
    image_url VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS user_inventory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    item_id INT,
    purchased_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES marketplace_items(id) ON DELETE CASCADE
);

-- Gym Classes
CREATE TABLE IF NOT EXISTS gym_classes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    trainer VARCHAR(100),
    category VARCHAR(50),
    difficulty ENUM('Beginner', 'Intermediate', 'Advanced', 'Elite'),
    start_time DATETIME,
    duration_mins INT,
    image_url VARCHAR(255)
);

-- Class Enrollments
CREATE TABLE IF NOT EXISTS enrollments (
    user_id INT,
    class_id INT,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, class_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (class_id) REFERENCES gym_classes(id) ON DELETE CASCADE
);

-- AI Generated Workout Plans
CREATE TABLE IF NOT EXISTS workout_plans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    plan_name VARCHAR(100),
    plan_data JSON, -- Stores the structured exercises
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Real-time Activity Logs (Vitals, Workouts, Nutrition)
CREATE TABLE IF NOT EXISTS activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    log_type ENUM('vital', 'exercise', 'nutrition', 'water'),
    val_primary DECIMAL(10,2), -- Heart rate, calories, ml, etc.
    val_secondary DECIMAL(10,2), -- BP, protein, etc.
    details TEXT,
    log_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Seed Initial Classes
INSERT INTO gym_classes (name, trainer, category, difficulty, start_time, duration_mins, image_url) VALUES 
('Titan Strength & Power', 'Marcus Thorne', 'Hypertrophy', 'Advanced', DATE_ADD(NOW(), INTERVAL 2 HOUR), 60, 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800'),
('Neon Yoga Flow', 'Sasha Luna', 'Flexibility', 'Beginner', DATE_ADD(NOW(), INTERVAL 4 HOUR), 45, 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800'),
('Cyber Cardio Burn', 'Jax Volt', 'HIIT', 'Elite', DATE_ADD(NOW(), INTERVAL 1 HOUR), 30, 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=800'),
('Core Matrix', 'Eva Core', 'Core', 'Intermediate', DATE_ADD(NOW(), INTERVAL 5 HOUR), 25, 'https://images.unsplash.com/photo-1518310383802-640c2de311b2?w=800');

-- Seed Marketplace
INSERT INTO marketplace_items (name, description, price, category, image_url) VALUES
('Cyber-Grit Badge', 'Show off your relentless nature with this neon-infused badge.', 500, 'badge', 'https://cdn-icons-png.flaticon.com/512/3135/3135810.png'),
('Titan Supplements', 'Digital performance boost. Increases daily credit earning by 5% for 24h.', 1200, 'boost', 'https://cdn-icons-png.flaticon.com/512/3014/3014389.png'),
('Neo-Weight Set', 'Advanced holographic weights for your virtual forge.', 3000, 'gear', 'https://cdn-icons-png.flaticon.com/512/3043/3043888.png');

-- Seed Initial Squads
INSERT INTO squads (name, description, logo_url) VALUES
('Apex Titans', 'Focus on maximum power and heavy compound lifting.', 'https://cdn-icons-png.flaticon.com/512/3242/3242257.png'),
('Neon Sprinters', 'The elite cardio and HIIT sector.', 'https://cdn-icons-png.flaticon.com/512/3242/3242258.png');
